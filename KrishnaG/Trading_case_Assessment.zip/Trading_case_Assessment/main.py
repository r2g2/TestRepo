from datetime import date, timedelta
import pandas as pd
from pathlib import Path
import os
import glob
import pathlib
import streamlit as st
import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s -%(message)s',
                    handlers=[logging.StreamHandler()])
logger =logging.getLogger(__name__)

def get_prices_contracts(base_filename,file_path):

    '''
    To extract data from the excel file and save it into dataframes.
    
    :base_filename: The base filename path to create dataframes dynamically.
    :file_path: The path where the uploaded file is stored.

    '''       
    try :
        entities =["price","contracts"] 
        dataframes_ = pd.read_excel(file_path, sheet_name=None)

        data_frames = {
            f"{base_filename}_{sheet.lower()}": df
            for sheet, df in dataframes_.items()
        }

        sheet_names = [key.lower().split('_')[-1] for key in data_frames.keys()]
                   
    
        if sheet_names != entities:
            error_msg = (
                "Invalid worksheet names in the excel file.\n"
                "Names should be:\n"
                "1. price\n"
                "2. contracts"
            )
            st.error(error_msg)
            raise ValueError(error_msg)

        #print("Read operation done successfully")
        logger.info(f"Read operation done successfully")
        return data_frames

    except Exception as ex:
        logger.info(f"An unexpected error while reading the excel file: {ex}")
        return None   # clearer than {}


def compute_MTM(row):
    '''
    To compute Market to Market value for each index.
    '''

    if "noadj" in row["base_index"].lower():
        fe_ratio = 1
    else:    
        fe_ratio = float(row["typical_fe"])/62
    
    if pd.isna(row["discount"]):
         row["discount"] = 1

    if row["unit"] == "DMT":
        MTMValue = ((row["price"] * fe_ratio)+ row["cost"]) * row["discount"] * row["quantity"]
    elif row["unit"] == "WMT":
        computed_quantity = row["quantity"] * (1 - float(row["moisture"]))
        MTMValue = ((row["price"] * fe_ratio)+ row["cost"]) * row["discount"] * computed_quantity
    
    return MTMValue



def generate_mtm_report(df_price,df_contracts):
    
    df_price.columns = [col.lower().replace(' ', '_') for col in df_price.columns]
    df_contracts.columns = [col.lower().replace(' ', '_') for col in df_contracts.columns]

    # renaming the coliumn so both dataframes have identical column names
    df_price.rename(columns={"index_name": "base_index"}, inplace=True)

    logger.info(f"No of rows in price dataframe {df_price.shape[0]}")
    logger.info(f"No of rows in contract dataframe {df_contracts.shape[0]}")

    logger.info(f"price dataframe column names-->{df_price.columns}")
    logger.info(f"contract dataframe column names -->{df_contracts.columns}")
   
    df = df_contracts.merge(df_price, on=["base_index", "tenor"])

    logger.info(f"final dataframe shape {df.shape}")
    
    if df.shape[0] > 0:

        df["mtm_value"] = df.apply(lambda row: compute_MTM(row), axis=1)

        valuation_date = date.today().strftime("%Y-%m-%d")
        # Save report
        filename = f"mtm_report_{valuation_date}.csv"
               
        result= df["mtm_value"].sum()
    else:  

        logger.info(f"No common contracts to execute ") 
        result = 0 
        

    return result, df

if __name__=="__main__":

    st.title("MTM Report Generation")
    dir_path= Path(__file__).parent / "data"
    dir_path.mkdir(parents=True, exist_ok=True)

    uploaded_file = st.file_uploader("Upload your Excel file", type=["xls", "xlsx"])

    if uploaded_file is not None:
        # Build the save path
        save_path = dir_path / uploaded_file.name
        
        # Save the uploaded file
        with open(save_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        upload_status = f"File '{uploaded_file.name}' uploaded and saved successfully at {save_path}."
        st.write(f"File '{uploaded_file.name}' uploaded and saved successfully.") 
    
    if st.button("Execute"):
        if upload_status:
        
            file_list = glob.glob(os.path.join(dir_path, "*.xlsx"))
            file_list.extend(glob.glob(os.path.join(dir_path, "*.xls")))

            logger.info(f"filelist-->{file_list}")

            file_path =file_list[0]
            base_filename= pathlib.Path(file_path).stem
            dataframes_list = get_prices_contracts(base_filename,file_path)
            
            if dataframes_list is not None and len(dataframes_list)> 0: 
                
                price_dataframe, contracts_dataframe = dataframes_list.values()
                
                if price_dataframe.empty and contracts_dataframe.empty:
                    result = "**No records for contracts and price Indices**"
                    result_df = pd.DataFrame()
                    st.write(result)  

                elif price_dataframe.empty:

                    result = "**No records for price Indices**"
                    result_df = pd.DataFrame()
                    st.write(result)

                elif contracts_dataframe.empty:

                    result = "**No records for contracts**"  
                    result_df = pd.DataFrame() 
                    st.write(result)

                elif dataframes_list[f"{base_filename}_price"].shape[0] > 0 and dataframes_list[f"{base_filename}_contracts"].shape[0]>0 :

                    result, result_df = generate_mtm_report(dataframes_list[f"{base_filename}_price"],dataframes_list[f"{base_filename}_contracts"])
    
                    
                if not isinstance(result_df,str):
                    valuation_date = date.today().strftime("%Y-%m-%d")
                    
                    if result_df.shape[0] > 0:   
                        csv_data = result_df.to_csv(index=False)
                        result_df.drop(['discount', 'tenor','moisture','counterparty','cost'], axis=1, inplace=True)
                        st.write(f"Generated report for MTM on {valuation_date}")
                        st.table(result_df)
                        st.write(f"**MTM value on {valuation_date} ---> {result}**")  
                        st.download_button(
                                label="📥 Download CSV",
                                data=csv_data,
                                file_name="MTM_Report.csv",
                                mime="text/csv"
                            )
                    else:
                        st.write("Sorry ! No results")    
                else:
                    st.write("Sorry ! No results")  
            else:
                st.write("Invalid file. Please upload the file again")          
        else:
            st.write("Invalid file1. Please upload the file again")
