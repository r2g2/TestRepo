import langchain
import os
import pandas as pd
import sqlalchemy
import streamlit as st
from sqlalchemy import create_engine,text
from pathlib import Path
from sqlalchemy import inspect
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_google_genai import GoogleGenerativeAI
import ast
from decimal import Decimal
from langchain.prompts import PromptTemplate
import pathlib
import re
import json
from dotenv import load_dotenv
load_dotenv() 

import logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s -%(message)s',
                    handlers=[logging.StreamHandler()])
logger =logging.getLogger(__name__)


    
def get_dataframes(csv_files):
    '''
    generate dataframe from the given csv shared files for daily and monthly percipitation.
    
    csv_files: list of filenames to be processed.

    '''
    tables_df_map={}

    print("length of csv files",len(csv_files))
    
    for file_name  in csv_files:
        if "daily" in file_name:
            path= Path(__file__).parent / "data" / file_name
            # print(path)
            daily_df  = pd.read_csv(path)
            logger.info(f"shape of the daily percipitation dataframe :{daily_df.shape}")
            logger.info(f"daily_df.columns:{daily_df.columns}")
            daily_df['Date'] = pd.to_datetime(daily_df['Date'],errors="coerce",dayfirst=True)
            daily_df.columns = [col.replace(' ', '_') for col in daily_df.columns]
            table_name1 = pathlib.Path(path).stem
            #print("table_name1",table_name1)
            tables_df_map[table_name1] =daily_df
        
        elif "monthly" in file_name:
            path= Path(__file__).parent / "data" / file_name
            monthly_df  = pd.read_csv(path)
            logger.info(f" shape of monthly percipitation dataframe:{monthly_df.shape}")
            logger.info(f" monthly_df.columns {monthly_df.columns}")
            monthly_df.columns = [col.replace(' ', '_') for col in monthly_df.columns]
            table_name2 = pathlib.Path(path).stem
            #print("table_name2",table_name2)
            tables_df_map[table_name2] = monthly_df

    #print(tables_df_map.items())   

    return tables_df_map


def connect_to_Database(config):
    '''
    Helps to connect to mysql DB
    
    config: provided with DB configuration details.
    '''

    DB_USER = config["db_user"]
    DB_PASS = config["db_password"]
    DB_HOST = config["db_host"]
    DB_PORT = config["db_port"]
    DB_NAME = config["db_name"]
    
    server_url = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}"
    engine = sqlalchemy.create_engine(server_url)
    try:
        with engine.connect() as conn:
            # Use 'text()' for raw SQL execution in modern SQLAlchemy versions
            conn.execute(text(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}"))
            conn.commit() # Commit the transaction (necessary for DDL in some cases)
            logger.info(f"DB created sucessfully")
    except Exception as ex:
        logger.error(f"An unexpected error occurred while Db creation: {ex}")      

    server_url = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = sqlalchemy.create_engine(server_url)

    return engine,server_url    

def import_tables_to_Database(engine,tables_df_map):
    '''
    Docstring for import_tables_to_Database
    
    :param engine: Description
    :param tables_df_map: Description
    '''

    try:
        inspector = inspect(engine)
        
        for table_name, _frame in tables_df_map.items():
            
            if not inspector.has_table(table_name):
                dtype_map = {}

                df = _frame.copy()
                for col in df.columns:

                    if col.lower() == "date":
                        dtype_map[col] = sqlalchemy.types.Date()

                    elif col.lower() == "month":
                        dtype_map[col] = sqlalchemy.types.Integer()

                    elif col.lower() in ["state", "district"]:
                        dtype_map[col] = sqlalchemy.types.String(100)

                    elif "precipitation" in col.lower():
                        dtype_map[col] = sqlalchemy.types.Numeric(10, 6)

                    else:
                        dtype_map[col] = sqlalchemy.types.String(255)

                    if len(dtype_map) == len(list(df.columns)):
                        df.to_sql(
                            table_name,
                            con=engine,
                            index=False,
                            if_exists="replace",
                            dtype=dtype_map
                        )

                logger.info(f"Created table: {table_name}")
                return True
           
        else:

               logger.info(f"table {table_name} imported sucessfully")  
        return True        

    except Exception as e:  
        logger.error(f" An unexpected error occurred while tables creation: {e}") 
        return False

#intilaize the LLM
llm = GoogleGenerativeAI(model="gemini-2.5-flash", google_api_key=os.environ["GOOGLE_API_KEY"])
#llm = GoogleGenerativeAI(model="gemini-pro", google_pi_key=os.environ["GOOGLE_API_KEY"])
#llm="llm"

# get the schema of the database
def get_schema(config):
    '''
    To get schema for the tables present in the database.

    '''
    DB_USER = config["db_user"]
    DB_PASS = config["db_password"]
    DB_HOST = config["db_host"]
    DB_PORT = config["db_port"]
    DB_NAME = config["db_name"]

    server_url = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

    db= SQLDatabase.from_uri(server_url,sample_rows_in_table_info=2)
    
    schema = db.get_table_info()

    return schema

def generate_prompt(table_schema,question,configuration):
    ''''
    To genertae prompt to  pass to LLM from table schema,, user question.

    '''

    prompt = PromptTemplate(

        input_variables=["schema", "question","database"],
        template="""
        You are a MySQL expert.Based on the table schema below in database , write a SQL query that would answer the user's question:
        Use ONLY the schema below in the database. when ever we perform aggregation on a column use alias name for it

        Database : {database}   

        Schema:
        {schema}

        Question:
        {question}

        Return ONLY the SQL query.
        """
        )
    
    prompt_text = prompt.format(
    schema=table_schema,
    question=question,
    database=configuration["db_name"]
            )
    
    return prompt_text


def execute_query (prompt_text,config):
    '''
    To pass the prompt genearted to LLM and get SQL query and pass the DB and get the results for the query.

    '''

    DB_USER = config["db_user"]
    DB_PASS = config["db_password"]
    DB_HOST = config["db_host"]
    DB_PORT = config["db_port"]
    DB_NAME = config["db_name"]


    server_url = f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    db= SQLDatabase.from_uri(server_url,sample_rows_in_table_info=2)

    logger.info(f"Final prompt before passing to LLM {prompt_text}")
    response = llm.invoke(prompt_text)
    llm_response= response.content if hasattr(response, "content") else response
    logger.info(f" Final LLM response:{llm_response}")
      
    pattern = r"^```(?:sql)?\s*|\s*```$"

    if re.search(pattern, llm_response, flags=re.IGNORECASE | re.MULTILINE):
        clean_sql = re.sub(pattern, "", llm_response, flags=re.IGNORECASE | re.MULTILINE)
    else:
        clean_sql = llm_response

    logger.info(f"clean_sql {clean_sql}")

    final_result = db.run(clean_sql) 

    with engine.connect() as conn:
        res=conn.execute(text(clean_sql))
        rows = res.fetchall()

    column_names = list(res.keys())

    logger.info(f"columns in the final result :{column_names}")
    logger.info(f" final sql query generated from the query:{final_result}")

    return final_result, column_names

if __name__=="__main__":   

    st.title("Weather Data Analysis")
    path = Path(__file__).parent 
    config_path = Path(__file__).parent / "config.json" 
    configuration = json.load(open(config_path))
    csv_path = Path(__file__).parent / "data"
    csv_files = [f.name for f in csv_path.glob("*.csv")]
    if len(csv_files) > 0:
        tables_df_map = get_dataframes(csv_files)
        engine,server_url = connect_to_Database(configuration)
        is_sucess = import_tables_to_Database(engine,tables_df_map)

    # if the insertion of tables is successful then only we proceed further for users question.
    if is_sucess:

        table_schema = get_schema(configuration)
             
        question = st.text_input("Enter your question:")
        prompt = generate_prompt(table_schema,question,configuration)

        if st.button("Execute"):
            if question:
                query_result,column_names = execute_query(prompt,configuration)
                logger.info(f"type of query_result {type(query_result)}")
                        
                if query_result is not None and len(query_result)>0:
                    st.write("Generated SQL Query:")
                    st.write("Query Result:")
                    if isinstance(query_result,str):
                        result_list = eval(query_result)
                    else:
                        result_list =  query_result 
                    if len(result_list)> 0:   
                        df = pd.DataFrame(result_list,columns=column_names)
                        st.table(df)
                    else:
                        st.write("Sorry ! No results for the above request")    
                else:
                    st.write("Sorry ! No results for the above request")  
            else:
                st.write("Please enter a question.")
    else:
        st.write("Please upload the file again.")            

#Testing senarios:

#What is the total precipitation amount of  state kerala in each month  August and September from year 2001 to 2005?  

#Compare the precipitation amount of states  tamil nadu and karnataka  in the  Nov 2006 in a table format.

#What is the total precipitation amount of  state andhra in each month  August and September from year 2001 to 2005?

#What is the total precipitation amount of  state kerala for  September from year 2001 to 2005?

# Compare the precipitation amount of  kerala and Maharashtra  in the second week of Nov 2004 in a table format

        