import pandas as pd
import numpy as np
from mtm import parse_moisture, parse_percent, month_end, select_price_for_contracts, compute_mtm

def test_parse_moisture():
    assert abs(parse_moisture("8%") - 0.08) < 1e-9
    assert abs(parse_moisture("0.08") - 0.08) < 1e-9
    assert abs(parse_moisture(8) - 0.08) < 1e-9
    assert parse_moisture(None) == 0.0

def test_parse_percent():
    assert abs(parse_percent("2%") - 0.02) < 1e-9
    assert abs(parse_percent("0.98") - 0.98) < 1e-9
    assert np.isnan(parse_percent("abc"))

def test_month_end():
    s = pd.Series(["2025-01-15", "2025-02-28", "2025-02-01"])
    me = month_end(s)
    assert me.iloc[0].day == 31
    assert me.iloc[1].day == 28

def test_select_price_and_compute_mtm():
    contracts = pd.DataFrame([
        {"Contract": "C1", "Index": "IndexA", "Tenor": "2025-01-10", "Quantity": 1000, "Unit": "WMT", "Moisture": "2%", "Typical Fe": 62.0, "Cost": 1.0, "Discount": "2%"},
        {"Contract": "C2", "Index": "IndexB", "Tenor": "2025-01-31", "Quantity": 500, "Unit": "DMT", "Typical Fe": 60.0, "Cost": 0.5, "Discount": 0.99},
    ])
    prices = pd.DataFrame([
        {"Index": "IndexA", "Tenor": "2025-01-03", "Price": 100.0},
        {"Index": "IndexA", "Tenor": "2025-01-31", "Price": 102.0},
        {"Index": "IndexB", "Tenor": "2025-01-15", "Price": 200.0},
    ])
    report = compute_mtm(contracts, prices)
    # basic shape and columns
    assert "MTM_Value" in report.columns
    # For C1, contract month end = 2025-01-31, Price should be 102.0
    c1 = report[report["ContractID"].astype(str).str.contains("C1")].iloc[0]
    assert abs(c1["BasePrice"] - 102.0) < 1e-9
    # DMT for C1 = 1000*(1-0.02)=980
    assert abs(c1["DMT"] - 980.0) < 1e-9

    c2 = report[report["ContractID"].astype(str).str.contains("C2")].iloc[0]
    # For typical fe 60 -> fe adj ratio = 60/62
    assert abs(c2["FeAdjRatio"] - (60.0/62.0)) < 1e-9