from pathlib import Path
import pandas as pd

def extract_workbook(path):
    p = Path(path)
    if not p.exists():
        raise SystemExit(f"Workbook not found: {p}")
    sheets = pd.read_excel(p, sheet_name=None, dtype=str)
    print(f"Found sheets: {list(sheets.keys())}")

    def pick(names):
        for n in names:
            if n in sheets:
                return n
        return None

    contracts_name = pick(["Contracts", "contracts", "Contract", "contract"])
    prices_name = pick(["Price", "Prices", "price", "prices", "Market Prices"])
    out_folder = p.parent / "extracted_data"
    out_folder.mkdir(exist_ok=True)

    try:
        if contracts_name:
            dfc = sheets[contracts_name]
            out_path = out_folder / "contracts.xlsx"
            dfc.to_excel(out_path, index=False, engine="openpyxl", sheet_name=contracts_name)
            print(f"Saved contracts -> {out_path}")
        else:
            print("Contracts sheet not found.")

        if prices_name:
            dfp = sheets[prices_name]
            out_path = out_folder / "prices.xlsx"
            dfp.to_excel(out_path, index=False, engine="openpyxl", sheet_name=prices_name)
            print(f"Saved prices -> {out_path}")
        else:
            print("Prices sheet not found.")
    except Exception as e:
        raise SystemExit(f"Failed to write Excel files: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python extract_and_save_data.py <workbook.xlsx>")
        raise SystemExit(1)
    extract_workbook(sys.argv[1])