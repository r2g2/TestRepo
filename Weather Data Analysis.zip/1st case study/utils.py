import pandas as pd
from pathlib import Path
from typing import Optional

def _read_first_matching_sheet(path: Path, candidates):
    xls = pd.ExcelFile(path)
    for name in candidates:
        if name in xls.sheet_names:
            return pd.read_excel(xls, sheet_name=name, dtype=str)
    # fallback to first sheet
    return pd.read_excel(xls, sheet_name=0, dtype=str)

def load_contracts(path) -> pd.DataFrame:
    """Load contracts sheet and return a dataframe (strings preserved)."""
    p = Path(path)
    df = _read_first_matching_sheet(p, ["Contracts", "contracts", "Contract", "contract"])
    # normalize column names
    df = df.rename(columns=lambda c: c.strip() if isinstance(c, str) else c)
    return df

def load_prices(path) -> pd.DataFrame:
    """Load prices sheet and return a dataframe (strings preserved)."""
    p = Path(path)
    df = _read_first_matching_sheet(p, ["Price", "Prices", "price", "prices", "Market Prices"])
    df = df.rename(columns=lambda c: c.strip() if isinstance(c, str) else c)
    return df

def save_report(df: pd.DataFrame, out_path: str):
    p = Path(out_path)
    if p.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        df.to_excel(p, index=False, engine="openpyxl")
    else:
        df.to_csv(p, index=False)