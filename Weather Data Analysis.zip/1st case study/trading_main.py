import argparse
from pathlib import Path
from utils import load_contracts, load_prices, save_report
from mtm import compute_mtm

def main():
    p = argparse.ArgumentParser(description="Generate MTM valuation report")
    p.add_argument("--contracts", "-c", help="Contracts Excel file", default="extracted_data/contracts.xlsx")
    p.add_argument("--prices", "-p", help="Prices Excel file", default="extracted_data/prices.xlsx")
    p.add_argument("--out", "-o", help="Output file (csv or xlsx)", default="mtm_report.csv")
    args = p.parse_args()

    contracts_file = Path(args.contracts)
    prices_file = Path(args.prices)
    out_file = Path(args.out)

    if not contracts_file.exists():
        raise SystemExit(f"Contracts file not found: {contracts_file}")
    if not prices_file.exists():
        raise SystemExit(f"Prices file not found: {prices_file}")

    contracts = load_contracts(contracts_file)
    prices = load_prices(prices_file)
    report = compute_mtm(contracts, prices)
    save_report(report, out_file)
    print(f"MTM report saved to: {out_file}")

if __name__ == "__main__":
    main()