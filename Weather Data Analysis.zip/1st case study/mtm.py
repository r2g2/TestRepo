from datetime import datetime
import pandas as pd
import numpy as np
from pandas.tseries.offsets import MonthEnd
from typing import Tuple

def _to_dt(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce")

def month_end(dt: pd.Series) -> pd.Series:
    return (_to_dt(dt) + MonthEnd(0)).dt.normalize()

def parse_percent(value) -> float:
    if pd.isna(value):
        return np.nan
    if isinstance(value, str):
        v = value.strip()
        if v.endswith("%"):
            try:
                return float(v.rstrip("%")) / 100.0
            except:
                return float(v) if v.replace(".", "", 1).isdigit() else np.nan
        try:
            return float(v)
        except:
            return np.nan
    try:
        return float(value)
    except:
        return np.nan

def parse_moisture(value) -> float:
    v = parse_percent(value)
    if pd.isna(v):
        return 0.0
    if v > 1:
        # interpret as percent points (e.g., 8 -> 0.08)
        v = v / 100.0
    return float(v)

def fe_adj_ratio(typical_fe, no_adj_flag) -> float:
    if isinstance(no_adj_flag, str) and no_adj_flag.strip().lower() in ("noadj", "no adj", "no_adjust", "no-adjust", "noadjust"):
        return 1.0
    if pd.isna(typical_fe):
        return 1.0
    try:
        return float(typical_fe) / 62.0
    except:
        return 1.0

# --- replace/patch below helper functions to guard against duplicate column names ---
def _dedupe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure DataFrame has unique column names by appending suffixes to duplicates."""
    cols = list(df.columns)
    seen = {}
    new_cols = []
    for c in cols:
        key = c if isinstance(c, str) else str(c)
        if key in seen:
            seen[key] += 1
            new_cols.append(f"{key}__{seen[key]}")
        else:
            seen[key] = 0
            new_cols.append(key)
    df = df.copy()
    df.columns = new_cols
    return df

def _ensure_unique_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Append small suffixes to duplicate column names to guarantee uniqueness."""
    cols = list(df.columns)
    seen = {}
    new_cols = []
    for c in cols:
        key = c if isinstance(c, str) else str(c)
        if key in seen:
            seen[key] += 1
            new_cols.append(f"{key}__dup{seen[key]}")
        else:
            seen[key] = 0
            new_cols.append(key)
    out = df.copy()
    out.columns = new_cols
    return out

def _prepare_prices(prices: pd.DataFrame, index_col_candidates=("Index", "IndexName", "Base Index", "BaseIndex", "index")) -> pd.DataFrame:
    df = _dedupe_columns(prices.copy())
    # try to find column names (case-insensitive)
    lower_map = {c.lower(): c for c in df.columns}
    possible_price_cols = [orig for lc, orig in lower_map.items() if "price" in lc]
    possible_tenor_cols = [orig for lc, orig in lower_map.items() if "tenor" in lc or "date" in lc]
    possible_index_cols = [orig for lc, orig in lower_map.items() if any(k.lower() in lc for k in index_col_candidates)]
    if not possible_price_cols:
        raise ValueError("No price column detected in prices sheet")
    price_col = possible_price_cols[0]
    tenor_col = possible_tenor_cols[0] if possible_tenor_cols else df.columns[0]
    index_col = possible_index_cols[0] if possible_index_cols else df.columns[0]
    df = df.rename(columns={price_col: "Price", tenor_col: "Tenor", index_col: "Index"})
    df = _ensure_unique_columns(df)   # <- ensure no duplicate labels after rename
    # ensure we select a Series even if duplicate labels existed originally
    df["Tenor"] = _to_dt(df.loc[:, "Tenor"])
    df["Price"] = pd.to_numeric(df.loc[:, "Price"], errors="coerce")
    df["Index"] = df.loc[:, "Index"].astype(str)
    df = df.dropna(subset=["Index"]).copy()
    df = df.sort_values(["Index", "Tenor"]).reset_index(drop=True)
    return df[["Index", "Tenor", "Price"]]

def _prepare_contracts(contracts: pd.DataFrame,
                       index_col_candidates=("Index", "IndexName", "Base Index", "BaseIndex", "index")) -> pd.DataFrame:
    df = _dedupe_columns(contracts.copy())
    # detect columns (case-insensitive map)
    cols = {c.lower(): c for c in df.columns}
    def find(keys):
        for k in keys:
            for lc, orig in cols.items():
                if k.lower() in lc:
                    return orig
        return None
    idx_col = find(["index", "base index", "indexname", "baseindex"]) or df.columns[0]
    tenor_col = find(["tenor", "date", "month"]) or df.columns[0]
    qty_col = find(["quantity", "qty", "volume"]) or df.columns[0]
    unit_col = find(["unit", "units"]) or None
    moist_col = find(["moisture", "moisture%", "moisture (%)"]) or None
    typical_fe_col = find(["typical fe", "fe", "typicalfe"]) or None
    cost_col = find(["cost", "costs"]) or None
    discount_col = find(["discount", "disc", "discount%"]) or None
    id_col = find(["contract", "contract id", "id"]) or None

    rename_map = {}
    rename_map[idx_col] = "Index"
    rename_map[tenor_col] = "Tenor"
    rename_map[qty_col] = "Quantity"
    if unit_col:
        rename_map[unit_col] = "Unit"
    if moist_col:
        rename_map[moist_col] = "Moisture"
    if typical_fe_col:
        rename_map[typical_fe_col] = "TypicalFe"
    if cost_col:
        rename_map[cost_col] = "Cost"
    if discount_col:
        rename_map[discount_col] = "Discount"
    if id_col:
        rename_map[id_col] = "ContractID"

    df = df.rename(columns=rename_map)
    df = _ensure_unique_columns(df)   # <- ensure unique labels here as well
    # ensure required cols exist
    if "Index" not in df.columns:
        df["Index"] = None
    if "Tenor" not in df.columns:
        df["Tenor"] = pd.NaT
    df["Tenor"] = _to_dt(df.loc[:, "Tenor"])
    df["ContractMonthEnd"] = month_end(df.loc[:, "Tenor"])
    df["Quantity"] = pd.to_numeric(df.get("Quantity"), errors="coerce").fillna(0.0)
    df["Unit"] = df.get("Unit").astype(str)
    if "Moisture" in df.columns:
        df["Moisture"] = df.loc[:, "Moisture"].apply(parse_moisture)
    else:
        df["Moisture"] = 0.0
    df["TypicalFe"] = pd.to_numeric(df.get("TypicalFe"), errors="coerce")
    df["Cost"] = pd.to_numeric(df.get("Cost"), errors="coerce").fillna(0.0)
    if "DiscountRaw" not in df.columns:
        df["DiscountRaw"] = df.get("Discount")
    # ensure ContractID exists and fill missing values with row index as string
    if "ContractID" in df.columns:
        df["ContractID"] = df["ContractID"].fillna(pd.Series(df.index.astype(str), index=df.index))
    else:
        df["ContractID"] = pd.Series(df.index.astype(str), index=df.index)
    return df

def select_price_for_contracts(contracts: pd.DataFrame, prices: pd.DataFrame) -> pd.DataFrame:
    """
    For each contract row, find the latest price record for same Index with Tenor <= ContractMonthEnd.
    Returns the contracts dataframe with columns Price and PriceTenor (the price record date).
    """
    prices_p = _prepare_prices(prices)
    contracts_p = _prepare_contracts(contracts)
    left = contracts_p.sort_values(["Index", "ContractMonthEnd"]).reset_index(drop=True)
    right = prices_p.sort_values(["Index", "Tenor"]).reset_index(drop=True)
    # merge_asof requires both left and right sorted by key
    merged = pd.merge_asof(
        left.sort_values("ContractMonthEnd"),
        right.sort_values("Tenor"),
        left_on="ContractMonthEnd",
        right_on="Tenor",
        by="Index",
        direction="backward"
    )
    merged = merged.rename(columns={"Price": "BasePrice", "Tenor": "PriceTenor"})
    return merged

def compute_mtm(contracts: pd.DataFrame, prices: pd.DataFrame) -> pd.DataFrame:
    df = select_price_for_contracts(contracts, prices)
    # discount parsing: if value like "2%" interpret as multiplier 0.98 or if value <=1 treat as multiplier already
    def discount_to_multiplier(v):
        dv = parse_percent(v)
        if pd.isna(dv):
            return 1.0
        if dv > 1:  # e.g., 2 -> 0.02? unlikely; treat >1 as percent points
            dv = dv / 100.0
        # if discount given as fraction (0.98) treat as multiplier
        if dv <= 1 and dv >= 0:
            # if dv looks like percent (0.02) and user meant discount=2% we must detect:
            # Heuristic: if original string contained '%' then treat as percent discount
            if isinstance(v, str) and "%" in v:
                return 1.0 - dv
            # if dv <= 1 but likely multiplier (e.g., 0.98) return as-is if >0.5 else assume percent?
            if dv > 0.5:
                return dv
            return 1.0 - dv
        return 1.0 - dv

    df["DiscountMultiplier"] = df["DiscountRaw"].apply(discount_to_multiplier)
    df["FeAdjRatio"] = df.apply(lambda r: fe_adj_ratio(r.get("TypicalFe"), r.get("DiscountRaw") if False else r.get("NoAdj") if "NoAdj" in r.index else r.get("NoAdj", None)), axis=1)
    # The above tries to detect NoAdj flag. If the original contracts include a field indicating NoAdj, user should include it.
    # For safety, also inspect a "NoAdj" or "FeAdj" column
    if "NoAdj" in df.columns:
        df["FeAdjRatio"] = df.apply(lambda r: fe_adj_ratio(r.get("TypicalFe"), r.get("NoAdj")), axis=1)
    else:
        # default: if there is a column "FeAdjust" or "FeAdj" which contains "NoAdj"
        if "FeAdjust" in df.columns:
            df["FeAdjRatio"] = df.apply(lambda r: fe_adj_ratio(r.get("TypicalFe"), r.get("FeAdjust")), axis=1)
    # compute DMT
    def compute_dmt(row):
        qty = float(row.get("Quantity") or 0.0)
        unit = str(row.get("Unit") or "").strip().lower()
        moisture = float(row.get("Moisture") or 0.0)
        if "wmt" in unit:
            return qty * (1.0 - moisture)
        return qty

    df["DMT"] = df.apply(compute_dmt, axis=1)
    # compute MTM: (BaseIndexPrice * FeAdjRatio + Cost) * Discount * Quantity(DMT)
    df["BasePrice"] = pd.to_numeric(df.get("BasePrice"), errors="coerce").fillna(0.0)
    df["MTM_Value"] = (df["BasePrice"] * df["FeAdjRatio"] + df["Cost"]) * df["DiscountMultiplier"] * df["DMT"]
    # helpful output columns
    out_cols = ["ContractID", "Index", "Tenor", "ContractMonthEnd", "PriceTenor", "BasePrice", "FeAdjRatio", "Cost", "DiscountRaw", "DiscountMultiplier", "Quantity", "Unit", "Moisture", "DMT", "MTM_Value"]
    existing = [c for c in out_cols if c in df.columns]
    return df[existing].copy()