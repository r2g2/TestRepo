
def query_monthly(con, intent):
    years = intent["years"]
    months = intent["months"]
    districts = intent["districts"]

    query = """
        SELECT
            Year,
            Month,
            State,
            District,
            SUM("Monthly Precipitation") AS precipitation
        FROM monthly
        WHERE 1=1
    """

    if years:
        query += f" AND Year BETWEEN {min(years)} AND {max(years)}"
    if months:
        query += f" AND Month IN ({','.join(map(str, months))})"
    if districts:
        query += f" AND District IN ({','.join(repr(d) for d in districts)})"

    query += " GROUP BY Year, Month, State, District ORDER BY Year, Month"

    return con.execute(query).df()
