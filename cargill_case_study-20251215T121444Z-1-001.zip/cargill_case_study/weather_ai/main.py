from weather_ai.db import get_connection
from weather_ai.intent_parser import parse_intent
from weather_ai.query_planner import choose_table
from weather_ai.query_engine import query_monthly
from weather_ai.response_formatter import format_response


def ask(question: str):
    intent = parse_intent(question)
    con = get_connection()

    table = choose_table(intent)

    if table == "monthly":
        df = query_monthly(con, intent)
    else:
        raise NotImplementedError("Daily queries handled separately")

    return format_response(df)


if __name__ == "__main__":
    query = "What is the total precipitation of Lucknow in August and September from 2001 to 2005?"
    print(ask(query))
