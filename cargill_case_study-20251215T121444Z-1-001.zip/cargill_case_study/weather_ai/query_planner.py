# weather_ai/query_planner.py

def choose_table(intent: dict) -> str:
    
    if intent.get("week"):
        return "daily"
    if intent.get("months"):
        return "monthly"
    return "monthly"
