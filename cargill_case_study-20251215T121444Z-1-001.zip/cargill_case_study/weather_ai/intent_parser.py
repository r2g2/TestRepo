import re
import spacy

nlp = spacy.load("en_core_web_sm")

MONTH_MAP = {
    "january": 1, "february": 2, "march": 3,
    "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9,
    "october": 10, "november": 11, "december": 12
}

def parse_intent(question: str) -> dict:
    doc = nlp(question.lower())

    intent = {
        "type": "aggregation",
        "districts": [],
        "states": [],
        "years": [],
        "months": [],
        "week": None
    }

    if "compare" in question:
        intent["type"] = "comparison"

    intent["years"] = list(map(int, re.findall(r"(20\\d{2})", question)))

    for token in doc:
        if token.text in MONTH_MAP:
            intent["months"].append(MONTH_MAP[token.text])

    for ent in doc.ents:
        if ent.label_ == "GPE":
            intent["districts"].append(ent.text.title())

    return intent
