import duckdb
from weather_ai.config import DAILY_FILE, MONTHLY_FILE


def get_connection():
    con = duckdb.connect(database=":memory:")

    con.execute(f"""
        CREATE TABLE daily AS
        SELECT * FROM read_excel('{DAILY_FILE}');
    """)

    con.execute(f"""
        CREATE TABLE monthly AS
        SELECT * FROM read_excel('{MONTHLY_FILE}');
    """)

    return con
