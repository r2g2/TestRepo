DAILY_FILE = "daily_precipitation.xlsx"
MONTHLY_FILE = "monthly_precipitation.xlsx"