import pandas as pd
from weather_ai.query_engine import query_monthly


def test_monthly_sum():
    df = pd.DataFrame({
        "Year": [2001, 2001],
        "Month": [8, 8],
        "State": ["UP", "UP"],
        "District": ["Lucknow", "Lucknow"],
        "Monthly Precipitation": [100, 200]
    })

    result = query_monthly(df, district=["Lucknow"], years=[2001], months=[8])
    assert result["Monthly Precipitation"].iloc[0] == 300
