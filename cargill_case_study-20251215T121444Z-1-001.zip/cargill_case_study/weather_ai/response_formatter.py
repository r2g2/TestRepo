# weather_ai/response_formatter.py

def format_response(df):
    if df.empty:
        return "No precipitation data found for the given query."

    return df.to_string(index=False)
