import pandas as pd
from weather_ai.config import DAILY_FILE, MONTHLY_FILE

def load_daily():
    df = pd.read_excel(DAILY_FILE)
    df['Date'] = pd.to_datetime(df['Date'])
    return df


def load_monthly():
    df = pd.read_excel(MONTHLY_FILE)
    return df