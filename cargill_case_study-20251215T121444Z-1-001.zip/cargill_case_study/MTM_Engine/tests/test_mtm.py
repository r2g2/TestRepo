
from mtm_engine.mtm_calculator import (
    calculate_fe_ratio,
    calculate_quantity_dmt,
    calculate_mtm
)


def test_fe_adjustment():
    assert calculate_fe_ratio("NoAdj", 60) == 1.0
    assert round(calculate_fe_ratio("Adj", 60), 4) == 0.9677


def test_quantity_conversion():
    assert calculate_quantity_dmt(100, "DMT", 0) == 100
    assert calculate_quantity_dmt(100, "WMT", 0.1) == 90


def test_mtm_calculation():
    mtm = calculate_mtm(100, 1, 5, 0.95, 100)
    assert mtm == 9975
