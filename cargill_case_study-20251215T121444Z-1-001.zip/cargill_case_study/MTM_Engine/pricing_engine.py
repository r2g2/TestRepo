import pandas as pd


def get_applicable_price(prices_df, index_name, tenor_date, valuation_date=None):
    

    if valuation_date is None:
        valuation_date = prices_df["Price Date"].max()

    pricing_date = min(tenor_date, valuation_date)

    subset = prices_df[
        (prices_df["Index Name"] == index_name) &
        (prices_df["Price Date"] <= pricing_date)
    ]

    if subset.empty:
        raise ValueError(
            f"No market price found for {index_name} on or before {pricing_date.date()}"
        )

    return subset.sort_values("date").iloc[-1]["price"]
