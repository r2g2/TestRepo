
import pandas as pd
from config import EXCEL_FILE, PRICE_SHEET, CONTRACT_SHEET
from file_utils import find_file


def load_data():
    excel_path = find_file("Trading Case Example Data.xlsx")

    prices = pd.read_excel(excel_path, sheet_name=PRICE_SHEET)
    contracts = pd.read_excel(excel_path, sheet_name=CONTRACT_SHEET)

    prices["Date"] = pd.to_datetime(prices["Price Date"])
    contracts["Tenor"] = pd.to_datetime(contracts["Tenor"])

    return prices, contracts
