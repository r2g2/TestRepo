import pandas as pd


def generate_report(records, output_file="MTM_Report.xlsx"):
    report_df = pd.DataFrame(records)
    report_df.to_excel(output_file, index=False)
    return report_df
