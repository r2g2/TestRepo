
from pathlib import Path


def find_file(filename: str, max_depth: int = 2) -> Path:
    
    base_dir = Path(__file__).resolve().parent

    search_paths = set()

    # Search upward
    current = base_dir
    for _ in range(max_depth + 1):
        search_paths.add(current)
        current = current.parent

    # Search downward
    for path in list(search_paths):
        for depth in range(max_depth):
            search_paths.update(
                p for p in path.glob("**/*") if p.is_dir()
            )

    for directory in search_paths:
        candidate = directory / filename
        if candidate.exists():
            return candidate.resolve()

    raise FileNotFoundError(
        f"File '{filename}' not found within {max_depth} levels up/down from {base_dir}"
    )
