from data_loader import load_data
from pricing_engine import get_applicable_price
from mtm_calculator import (
    calculate_fe_ratio,
    calculate_quantity_dmt,
    calculate_mtm,
)
from report_generator import generate_report
from validations import validate_contract_row


def run_mtm():
    prices, contracts = load_data()
    results = []

    for _, c in contracts.iterrows():
        validate_contract_row(c)

        base_price = get_applicable_price(
            prices,
            c["Base Index"],
            c["Tenor"]
        )

        fe_ratio = calculate_fe_ratio(
                            c.get("Typical Fe")
                        )

        quantity_dmt = calculate_quantity_dmt(
            c["Quantity"],
            c["Unit"],
            c.get("Moisture", 0)
        )

        mtm_value = calculate_mtm(
            base_price,
            fe_ratio,
            c["Cost"],
            c["Discount"],
            quantity_dmt
        )

        results.append({
            "Contract ID": c["Contract ID"],
            "Index": c["Base Index"],
            "Tenor": c["Tenor"].date(),
            "MTM Value": round(mtm_value, 2)
        })

    generate_report(results)


if __name__ == "__main__":
    run_mtm()
