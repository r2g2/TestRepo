
import pandas as pd


def validate_contract_row(row):
    
    # Quantity must exist and be positive
    if pd.isna(row.get("Quantity")) or row.get("Quantity") <= 0:
        raise ValueError("Quantity must be present and greater than zero")

    # Unit validation
    if row.get("Unit") not in ("DMT", "WMT"):
        raise ValueError(f"Invalid Unit value: {row.get('Unit')}")

    # Moisture is mandatory only for WMT
    if row.get("Unit") == "WMT":
        if pd.isna(row.get("Moisture")):
            raise ValueError("Moisture is required when Unit is WMT")
        if not (0 <= row.get("Moisture") < 1):
            raise ValueError("Moisture must be between 0 and 1")

    # Typical Fe is optional, but if present must be valid
    if not pd.isna(row.get("Typical Fe")):
        if row.get("Typical Fe") <= 0:
            raise ValueError("Typical Fe must be a positive number")

    # Commercial checks
    if pd.isna(row.get("Discount")):
        raise ValueError("Discount is required")

    if pd.isna(row.get("Cost")):
        raise ValueError("Cost is required")
