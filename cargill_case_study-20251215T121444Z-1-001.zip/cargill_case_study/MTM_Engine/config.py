EXCEL_FILE = "Trading Case Example Data.xlsx"
PRICE_SHEET = "Price"
CONTRACT_SHEET = "Contracts"