
def calculate_fe_ratio(typical_fe):
    
    if typical_fe is None:
        return 1.0

    if float(typical_fe) == 62:
        return 1.0

    return float(typical_fe) / 62


def calculate_quantity_dmt(quantity, unit, moisture):
    if unit == "DMT":
        return quantity
    if unit == "WMT":
        return quantity * (1 - moisture)
    raise ValueError(f"Unknown unit: {unit}")


def calculate_mtm(base_price, fe_ratio, cost, discount, quantity_dmt):
    return (base_price * fe_ratio + cost) * discount * quantity_dmt
