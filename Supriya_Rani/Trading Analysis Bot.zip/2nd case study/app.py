import streamlit as st
from graph.workflow import workflow

st.set_page_config(page_title="Weather AI", layout="wide")
st.title("🌧️ Weather Analysis Bot")
st.write("Ask any question about precipitation.")

question = st.text_input("Enter your question:")

if st.button("Analyze"):
    with st.spinner("Processing..."):
        final_state = workflow.invoke({"question": question})
        st.success("Analysis Complete!")
        st.subheader("💡 Answer:")
        st.write(final_state.get("answer", "No answer produced."))

        st.subheader("📊 Raw Result:")
        st.write(final_state.get("result", "No raw result generated."))

