import pandas as pd
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

daily_df = pd.read_excel("data/daily_precip.xlsx")

emb = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

texts = []
for row in daily_df[['state', 'district']].drop_duplicates().itertuples():
    texts.append(f"District: {row.district}; State: {row.state}")

db = FAISS.from_texts(texts, emb)
db.save_local("data/region_index")

print("FAISS index created at data/region_index")
