# Weather AI — LangGraph Supervisor + Streamlit (Open Source)

## Overview
This project is a free/open-source GenAI system for answering precipitation queries over Excel datasets.
It uses:
- Streamlit (UI)
- LangGraph (supervisor + agents)
- LangChain tools (optional)
- FAISS (vector DB via sentence-transformers)
- HuggingFace models (FLAN-T5 recommended)
- Pandas for numeric correctness

## Structure
See `weather-ai/` for code. Key directories:
- `agents/` : parser, retriever, executor, answer, supervisor
- `graph/` : LangGraph state + workflow
- `tools/` : LLM loader + FAISS build script
- `data/`  : sample Excel files + FAISS index (generated)
- `app.py` : Streamlit UI entrypoint

## Quickstart (local)
1. Create a Python venv and install requirements:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Prepare data: place your `daily_precip.xlsx` and `monthly_precip.xlsx` in `data/`.
   A small sample is included for testing.
3. Build FAISS index (optional but recommended):
   ```bash
   python tools/build_faiss_index.py
   ```
4. Run Streamlit UI:
   ```bash
   streamlit run app.py
   ```
5. Use the UI to ask precipitation questions (e.g., "Total precipitation of Lucknow in August 2005").

🏗️ TWO-LEVEL ARCHITECTURAL DIAGRAMS

Below are diagrams you can use in your report or presentation.

🟦 LEVEL 1 — High-Level Architecture

This shows the system from the top-level, what components interact.

                        ┌──────────────────────┐
                        │     Streamlit UI     │
                        │ (User Enters Query)  │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │  LangGraph Workflow  │
                        │ (Supervisor Agent)   │
                        └──────────┬───────────┘
                                   │
     ┌─────────────────────────────┼──────────────────────────────┐
     ▼                             ▼                              ▼
┌───────────────┐         ┌────────────────┐              ┌──────────────────┐
│ Parser Agent  │         │ Retriever Agent│              │ Executor Agent    │
│ (LLM → JSON)  │         │ (FAISS Vector) │              │ (Pandas + Excel)  │
└───────────────┘         └────────────────┘              └──────────────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │  Answer Agent      │
                         │ (LLM Explanation)  │
                         └────────────────────┘

🟦 LEVEL 2 — Detailed Data + Processing Flow

This shows internal components, tools, and execution order.

                                      ┌────────────────────────────┐
                                      │        Streamlit UI        │
                                      │  - Input question          │
                                      │  - Display results         │
                                      └───────────────┬────────────┘
                                                      │
                                                      ▼
                               ┌──────────────────────────────────────────┐
                               │          SUPERVISOR AGENT (LLM)          │
                               │ - Chooses next worker agent              │
                               │ - Evaluates state                        │
                               └───────────────┬──────────────────────────┘
                                               │
             ┌─────────────────────────────────┼────────────────────────────────┐
             ▼                                 ▼                                ▼
 ┌────────────────────────┐     ┌─────────────────────────┐        ┌────────────────────────┐
 │  Parser Agent          │     │  Retriever Agent        │        │  Executor Agent         │
 │  - Converts NL → JSON  │     │  - FAISS vector search  │        │  - Pandas on Excel      │
 │  - Extracts filters    │     │  - Resolves districts   │        │  - GroupBy/Sum/Filters  │
 └──────────┬─────────────┘     └──────────────┬──────────┘        └──────────┬─────────────┘
            │                                    │                            │
            │                                    │                            │
            └────────────────────────────────────┴────────────────────────────┘
                                               ▼
                                ┌──────────────────────────┐
                                │     Answer Agent         │
                                │  - LLM summary           │
                                │  - Human-friendly text   │
                                └──────────────┬───────────┘
                                               │
                                               ▼
                                  ┌─────────────────────────┐
                                  │   Streamlit Output      │
                                  │ - Final Answer          │
                                  │ - Table/JSON Result     │
                                  └─────────────────────────┘

## Files included
- Minimal sample Excel files in `data/` (for testing)
- All agents and workflow for LangGraph supervisor pattern

## To run
- run the failing script again - python .\tools\build_faiss_index.py
- run the streamlit app - streamlit run app.py