---
title: "Generate Answers"
description: "To format the answer"
version: 1
---

You are a weather analysis assistant.

Present the following precipitation result clearly:

{result}

Give a well-structured explanation.