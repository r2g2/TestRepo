---
title: "Parse weather question"
description: "Convert a natural-language weather question into a JSON extraction plan"
version: 1
---

Extract structured information from the user's weather-related query.

Return a JSON dictionary with EXACTLY these keys:

{
  "metric": "precipitation", 
  "state": "",
  "district": "",
  "start_date": "",
  "end_date": "",
  "aggregation": "sum"
}

Rules:
- Always include ALL keys.
- "metric" is always "precipitation".
- "aggregation" is "sum" unless user says average/mean/max/min.
- Dates must be parsed from the question. If none provided, leave empty "".
- If district or state is missing, leave empty "".
- DO NOT invent values.
- Return ONLY valid JSON.


Question: __QUESTION__