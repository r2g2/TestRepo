def supervisor_decision(state):
    """
    Supervisor decides which agent should run next.
    Ensures proper pipeline:
    question → parser → retriever → executor → answer → finish
    """

    question = state.get("question")
    plan = state.get("plan")
    retrieved = state.get("retrieved")
    result = state.get("result")
    answer = state.get("answer")

    # 1. If question exists but no plan → run parser
    if question and not plan:
        return "parser_agent"

    # 2. After parser: need retrieval
    # Avoid infinite loops by checking retrieved is None, not falsy
    if plan is not None and retrieved is None:
        return "retriever_agent"

    # 3. After retrieval: need execution
    if retrieved is not None and result is None:
        return "executor_agent"

    # 4. After execution: need answer generation
    if result is not None and answer is None:
        return "answer_agent"

    # 5. Done
    return "FINISH"
