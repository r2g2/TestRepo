from langchain.tools import tool
from tools.llm_loader import load_llm
from pathlib import Path
import json

llm = load_llm()
PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "parser_prompt.md"

@tool("parse_weather_question")
def parse_weather_question(question: str):
    """Parse the user's natural language weather question into a structured JSON plan."""

    template = PROMPT_PATH.read_text(encoding="utf-8")
    prompt = template + "\n\nUser query:\n" + question

    llm_output = llm(prompt)[0]["generated_text"]

    # Attempt JSON parse
    try:
        plan = json.loads(llm_output)
    except Exception:
        plan = {}

    # Required schema (ensures keys ALWAYS exist)
    required = {
        "metric": "precipitation",
        "state": "",
        "district": "",
        "start_date": "",
        "end_date": "",
        "aggregation": "sum"
    }

    for key, default_val in required.items():
        if key not in plan:
            plan[key] = default_val

    return plan
