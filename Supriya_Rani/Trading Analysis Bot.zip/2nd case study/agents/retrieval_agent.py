from langchain.tools import tool
from langchain.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

embedding = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

db = FAISS.load_local("data/region_index", embedding, allow_dangerous_deserialization=True)


@tool("search_region")
def search_region(query: str):
    """Retrieve the most relevant region (state/district) information from vector DB."""
    try:
        docs = db.similarity_search(query, k=3)
        return [d.page_content for d in docs]
    except Exception:
        return []
