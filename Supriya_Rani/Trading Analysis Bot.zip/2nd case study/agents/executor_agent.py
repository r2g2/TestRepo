from langchain.tools import tool
import pandas as pd
from pathlib import Path

DATA_DAILY = Path("data/daily_precip.xlsx")
DATA_MONTHLY = Path("data/monthly_precip.xlsx")

daily_df = pd.read_excel(DATA_DAILY)
monthly_df = pd.read_excel(DATA_MONTHLY)

@tool("execute_precipitation_query")
def execute_precipitation_query(plan: dict):
    """Execute precipitation query using the parsed plan."""

    # Extract values safely
    state = plan.get("state", "")
    district = plan.get("district", "")
    start_date = plan.get("start_date", "")
    end_date = plan.get("end_date", "")
    aggregation = plan.get("aggregation", "sum")
    metrics = plan.get("metrics", "precipitation")

    df = daily_df.copy()

    if state:
        df = df[df["State"].str.contains(state, case=False, na=False)]

    if district:
        df = df[df["District"].str.contains(district, case=False, na=False)]

    if start_date:
        df = df[df["Date"] >= pd.to_datetime(start_date)]

    if end_date:
        df = df[df["Date"] <= pd.to_datetime(end_date)]

    if df.empty:
        return {"message": "No data found for given filters."}

    value = None
    if aggregation == "sum":
        value = df["Daily Precipitation"].sum()
    elif aggregation == "mean":
        value = df["Daily Precipitation"].mean()
    elif aggregation == "max":
        value = df["Daily Precipitation"].max()
    elif aggregation == "min":
        value = df["Daily Precipitation"].min()

    return {
        "rows": len(df),
        "aggregation": aggregation,
        "value": float(value),
        "filters": plan,
        "metrics": metrics,
    }
