from pathlib import Path
from langchain.tools import tool
from tools.llm_loader import load_llm

llm = load_llm()
PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "generate_answer.md"

@tool("answer_agent")
def answer_agent(result: str):
    """Convert the execution result into a clean, human-friendly answer."""

    template = PROMPT_PATH.read_text(encoding="utf-8")
    prompt = template.replace("{result}", result)

    out = llm(prompt)[0]["generated_text"]
    return out
