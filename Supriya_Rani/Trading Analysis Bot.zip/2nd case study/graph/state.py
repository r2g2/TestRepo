from typing import Dict, Any, Optional
from langgraph.graph import MessagesState

class WeatherState(MessagesState):
    question: str
    plan: Optional[Dict]
    retrieved: Optional[Any]
    result: Optional[Any]
    answer: Optional[str]
    next: Optional[str]
