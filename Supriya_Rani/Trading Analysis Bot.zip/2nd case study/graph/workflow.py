from langgraph.graph import StateGraph, END
from graph.state import WeatherState

from agents.parser_agent import parse_weather_question
from agents.retrieval_agent import search_region
from agents.executor_agent import execute_precipitation_query
from agents.answer_agent import answer_agent
from agents.supervisor_agent import supervisor_decision

def parser_node(state):
    plan = parse_weather_question.run(state["question"])
    return {"plan": plan}

def retriever_node(state):
    retrieved = search_region.run(state["question"])
    return {"retrieved": retrieved}

def executor_node(state):
    result = execute_precipitation_query.run(state["plan"])
    return {"result": result}

def answer_node(state):
    answer = answer_agent.run(str(state["result"]))
    return {"answer": answer}

def supervisor(state):
    n = supervisor_decision(state)
    return {"next": n}

graph = StateGraph(WeatherState)

graph.add_node("supervisor", supervisor)
graph.add_node("parser_agent", parser_node)
graph.add_node("retriever_agent", retriever_node)
graph.add_node("executor_agent", executor_node)
graph.add_node("answer_agent", answer_node)

graph.set_entry_point("supervisor")

graph.add_conditional_edges(
    "supervisor",
    lambda s: s["next"],
    {
        "parser_agent": "parser_agent",
        "retriever_agent": "retriever_agent",
        "executor_agent": "executor_agent",
        "answer_agent": "answer_agent",
        "FINISH": END,
    },
)

graph.add_edge("parser_agent", "supervisor")
graph.add_edge("retriever_agent", "supervisor")
graph.add_edge("executor_agent", "supervisor")

workflow = graph.compile()
