# GenAI Appendix – Tools & Prompts

Tool used: ChatGPT (OpenAI).

## Prompts used (summary)
1. "Read the assessment requirements and propose a deployable folder structure with CLI, tests, and example outputs."
2. "Implement MTM valuation logic per formula: (BasePrice * FeAdjRatio + Cost) * Discount * Quantity, including WMT→DMT and month-end tenor normalization."
3. "Create a deterministic NLQ parser for precipitation questions; back it with DuckDB SQL; provide a CLI and optional FastAPI API."
4. "Generate example outputs and include a README with run steps."

No external/private datasets were provided to the model beyond the files attached in the conversation.
