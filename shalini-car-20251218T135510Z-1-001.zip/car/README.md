# Ready-to-submit package

This submission contains **two independent solutions**, one for each assessment you uploaded:

1) `trading_mtm/` – MTM valuation report generator (reads provided Excel)
2) `weather_assistant/` – precipitation analysis assistant (NL question → query → answer)

Each folder has its own `README.md`, `requirements.txt`, source code, and tests.

## What you do before submitting

### 1) Trading MTM
- Run:
  ```bash
  cd trading_mtm
  pip install -r requirements.txt
  python -m trading_mtm.cli generate-report --input "data/Trading Case Example Data.xlsx" --outdir outputs
  ```
- Confirm `outputs/mtm_report_latest.xlsx` exists (example report required).

### 2) Weather assistant
- Run:
  ```bash
  cd weather_assistant
  pip install -r requirements.txt
  python -m weather_assistant.cli ingest --daily "data/sample_daily_precip.csv" --monthly "data/sample_monthly_precip.csv" --db "data/precip.duckdb"
  python -m weather_assistant.cli ask --db "data/precip.duckdb" --q "What is the total precipitation amount of district Lucknow in each August and September from year 2001 to 2005?"
  ```
- `outputs_example.md` is included as an example report (from the sample data).

### 3) GenAI appendix
- See `docs/appendix_prompts.md` and submit it if the assessment requires it.
