import pytest
from weather_assistant.nlq import parse

def test_parse_district_months():
    plan = parse("What is the total precipitation amount of district Lucknow in each August and September from year 2001 to 2005?")
    assert plan.kind == "district_month_totals"
    assert "monthly_precip" in plan.sql

def test_parse_state_week():
    plan = parse("Compare the precipitation amount of state Uttar Pradesh and state Maharashtra in the second week of Nov 2025 in a table format.")
    assert plan.kind == "state_week_compare"
    assert "daily_precip" in plan.sql

def test_parse_unsupported():
    with pytest.raises(ValueError):
        parse("Show me median rainfall trends with anomaly detection.")
