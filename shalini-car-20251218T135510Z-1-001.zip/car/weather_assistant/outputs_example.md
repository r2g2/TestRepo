# Example Answers (from included sample data)

## Q1
**What is the total precipitation amount of district Lucknow in each August and September from year 2001 to 2005?**

|   year |   month | district   |   monthly_precip |
|-------:|--------:|:-----------|-----------------:|
|   2001 |       8 | Lucknow    |          54.0773 |
|   2001 |       9 | Lucknow    |          58.539  |
|   2002 |       8 | Lucknow    |          79.5149 |
|   2002 |       9 | Lucknow    |          97.4289 |
|   2003 |       8 | Lucknow    |          52.7317 |
|   2003 |       9 | Lucknow    |          60.7595 |
|   2004 |       8 | Lucknow    |          77.3179 |
|   2004 |       9 | Lucknow    |          62.5265 |
|   2005 |       8 | Lucknow    |          65.2271 |
|   2005 |       9 | Lucknow    |          78.6126 |

## Q2
**Compare the precipitation amount of state Uttar Pradesh and state Maharashtra in the second week of Nov 2005 in a table format.**

| state         |   total_precip |
|:--------------|---------------:|
| Maharashtra   |        35.4892 |
| Uttar Pradesh |        32.0905 |
