# Weather Data Analysis – AI Assistant (Python)

This solution provides a small **Natural Language → Query → Answer** assistant for precipitation analysis.

It is designed for large datasets (>1M rows) by loading data into **DuckDB** (columnar execution) and using
pre-aggregated monthly data when possible.

## Quickstart (CLI)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Build a local DuckDB database from your source files
python -m weather_assistant.cli ingest \
  --daily "data/sample_daily_precip.csv" \
  --monthly "data/sample_monthly_precip.csv" \
  --db "data/precip.duckdb"

# Ask questions
python -m weather_assistant.cli ask --db "data/precip.duckdb" \
  --q "What is the total precipitation amount of district Lucknow in each August and September from year 2001 to 2005?"
```

## Optional API (FastAPI)

```bash
uvicorn weather_assistant.api:app --reload
```

POST `/ask` with JSON: `{ "question": "...", "db_path": "data/precip.duckdb" }`

## Supported question patterns (deterministic)
- **District totals by month across a year range**, e.g.
  - "total precipitation of district A in each August and September from year 2001 to 2005"
- **Compare states over a specific week**, e.g.
  - "Compare the precipitation amount of state A and state B in the second week of Nov 2025 in a table format."

If a question falls outside patterns, the assistant returns a helpful error and shows the closest supported template.

## Where to look
- `src/weather_assistant/nlq.py` parses questions into a structured query plan
- `src/weather_assistant/engine.py` executes plans via DuckDB
- `src/weather_assistant/api.py` optional API wrapper
