from __future__ import annotations

from pathlib import Path
import typer
from rich.console import Console
from rich.table import Table

from .engine import connect, ingest_csv, run_plan
from .nlq import parse

app = typer.Typer(add_completion=False)
console = Console()


@app.command("ingest")
def ingest(
    daily: Path = typer.Option(None, "--daily", help="Daily precipitation CSV (date,state,district,daily_precip)"),
    monthly: Path = typer.Option(None, "--monthly", help="Monthly precipitation CSV (year,month,state,district,monthly_precip)"),
    db: Path = typer.Option(Path("data/precip.duckdb"), "--db", help="DuckDB database path"),
):
    db.parent.mkdir(parents=True, exist_ok=True)
    con = connect(db)
    ingest_csv(con, str(daily) if daily else None, str(monthly) if monthly else None)
    console.print(f"[bold green]Ingested[/] into {db}")


@app.command("ask")
def ask(
    db: Path = typer.Option(Path("data/precip.duckdb"), "--db", help="DuckDB database path"),
    q: str = typer.Option(..., "--q", help="Question in natural language"),
):
    con = connect(db)
    plan = parse(q)
    df = run_plan(con, plan)
    console.print(f"[bold]{plan.title}[/]")
    if df.empty:
        console.print("[yellow]No rows matched the query.[/]")
        raise typer.Exit(code=0)

    table = Table(show_lines=True)
    for col in df.columns:
        table.add_column(str(col))
    for _, row in df.iterrows():
        table.add_row(*[str(x) for x in row.values.tolist()])
    console.print(table)


def main():
    app()


if __name__ == "__main__":
    main()
