from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import List, Optional, Tuple

from dateutil.relativedelta import relativedelta

from .engine import QueryPlan

MONTHS = {
    "JAN": 1, "JANUARY": 1,
    "FEB": 2, "FEBRUARY": 2,
    "MAR": 3, "MARCH": 3,
    "APR": 4, "APRIL": 4,
    "MAY": 5,
    "JUN": 6, "JUNE": 6,
    "JUL": 7, "JULY": 7,
    "AUG": 8, "AUGUST": 8,
    "SEP": 9, "SEPT": 9, "SEPTEMBER": 9,
    "OCT": 10, "OCTOBER": 10,
    "NOV": 11, "NOVEMBER": 11,
    "DEC": 12, "DECEMBER": 12,
}

WEEK_ORD = {"FIRST":1,"1ST":1,"SECOND":2,"2ND":2,"THIRD":3,"3RD":3,"FOURTH":4,"4TH":4}


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip())


def parse(question: str) -> QueryPlan:
    q = _norm(question)
    uq = q.upper()

    # Pattern 1: district totals by month(s) over year range
    # Example: "total precipitation amount of district Lucknow in each August and September from year 2001 to 2005"
    m = re.search(
        r"TOTAL\s+PRECIPITATION.*DISTRICT\s+(?P<district>[A-Z \-]+?)\s+IN\s+EACH\s+(?P<m1>[A-Z]+)(?:\s+AND\s+(?P<m2>[A-Z]+))?\s+FROM\s+YEAR\s+(?P<y1>\d{4})\s+TO\s+(?P<y2>\d{4})",
        uq,
    )
    if m:
        district = _norm(m.group("district").title())
        y1, y2 = int(m.group("y1")), int(m.group("y2"))
        m1 = MONTHS.get(m.group("m1"), None)
        m2 = MONTHS.get(m.group("m2"), None) if m.group("m2") else None
        months = [m for m in [m1, m2] if m is not None]
        if not months:
            raise ValueError("Could not parse month names in the question.")
        month_list = ",".join(str(x) for x in months)
        sql = f"""
            SELECT year, month, district, SUM(monthly_precip) AS total_precip
            FROM monthly_precip
            WHERE district = '{district}'
              AND year BETWEEN {y1} AND {y2}
              AND month IN ({month_list})
            GROUP BY year, month, district
            ORDER BY year, month;
        """
        return QueryPlan(
            kind="district_month_totals",
            title=f"Total precipitation for district {district} by month ({', '.join(map(str, months))})",
            sql=sql,
        )

    # Pattern 2: compare state A and B in Nth week of a month/year
    # Example: "Compare ... state A and state B in the second week of Nov 2025"
    m = re.search(
        r"COMPARE.*STATE\s+(?P<s1>[A-Z \-]+?)\s+AND\s+STATE\s+(?P<s2>[A-Z \-]+?)\s+IN\s+THE\s+(?P<ord>FIRST|1ST|SECOND|2ND|THIRD|3RD|FOURTH|4TH)\s+WEEK\s+OF\s+(?P<mon>[A-Z]+)\s+(?P<year>\d{4})",
        uq,
    )
    if m:
        s1 = _norm(m.group("s1").title())
        s2 = _norm(m.group("s2").title())
        ordw = WEEK_ORD[m.group("ord")]
        mon = MONTHS.get(m.group("mon"), None)
        year = int(m.group("year"))
        if mon is None:
            raise ValueError("Could not parse month name in the question.")
        # define week as days [1-7], [8-14], [15-21], [22-28] within the month
        start_day = 1 + (ordw - 1) * 7
        end_day = start_day + 6
        sql = f"""
            WITH rng AS (
                SELECT
                    DATE '{year:04d}-{mon:02d}-{start_day:02d}' AS d1,
                    DATE '{year:04d}-{mon:02d}-{end_day:02d}' AS d2
            )
            SELECT state, SUM(daily_precip) AS total_precip
            FROM daily_precip, rng
            WHERE date BETWEEN rng.d1 AND rng.d2
              AND state IN ('{s1}', '{s2}')
            GROUP BY state
            ORDER BY state;
        """
        return QueryPlan(
            kind="state_week_compare",
            title=f"Compare states {s1} vs {s2} in week {ordw} of {mon}/{year}",
            sql=sql,
        )

    raise ValueError(
        "Unsupported question format. Supported examples:\n"
        "- What is the total precipitation amount of district A in each August and September from year 2001 to 2005?\n"
        "- Compare the precipitation amount of state A and state B in the second week of Nov 2025 in a table format."
    )
