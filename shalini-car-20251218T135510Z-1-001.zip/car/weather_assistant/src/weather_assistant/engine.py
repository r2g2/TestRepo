from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import duckdb
import pandas as pd


@dataclass(frozen=True)
class QueryPlan:
    kind: str
    sql: str
    title: str


def connect(db_path: str | Path) -> duckdb.DuckDBPyConnection:
    return duckdb.connect(str(db_path))


def ensure_schema(con: duckdb.DuckDBPyConnection) -> None:
    con.execute("""
    CREATE TABLE IF NOT EXISTS daily_precip(
        date DATE,
        state VARCHAR,
        district VARCHAR,
        daily_precip DOUBLE
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS monthly_precip(
        year INTEGER,
        month INTEGER,
        state VARCHAR,
        district VARCHAR,
        monthly_precip DOUBLE
    );
    """)


def ingest_csv(con: duckdb.DuckDBPyConnection, daily_path: Optional[str], monthly_path: Optional[str]) -> None:
    ensure_schema(con)
    if daily_path:
        con.execute("DELETE FROM daily_precip;")
        con.execute(f"""
            INSERT INTO daily_precip
            SELECT
                CAST(date AS DATE) AS date,
                state,
                district,
                CAST(daily_precip AS DOUBLE) AS daily_precip
            FROM read_csv_auto('{daily_path}', header=True);
        """)
    if monthly_path:
        con.execute("DELETE FROM monthly_precip;")
        con.execute(f"""
            INSERT INTO monthly_precip
            SELECT
                CAST(year AS INTEGER) AS year,
                CAST(month AS INTEGER) AS month,
                state,
                district,
                CAST(monthly_precip AS DOUBLE) AS monthly_precip
            FROM read_csv_auto('{monthly_path}', header=True);
        """)


def run_plan(con: duckdb.DuckDBPyConnection, plan: QueryPlan) -> pd.DataFrame:
    return con.execute(plan.sql).df()
