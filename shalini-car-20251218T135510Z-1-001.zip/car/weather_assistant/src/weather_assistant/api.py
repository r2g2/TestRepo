from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path

from .engine import connect, run_plan
from .nlq import parse

app = FastAPI(title="Weather Precipitation Assistant")


class AskRequest(BaseModel):
    question: str
    db_path: str = "data/precip.duckdb"


@app.post("/ask")
def ask(req: AskRequest):
    con = connect(Path(req.db_path))
    plan = parse(req.question)
    df = run_plan(con, plan)
    return {"title": plan.title, "rows": df.to_dict(orient="records")}
