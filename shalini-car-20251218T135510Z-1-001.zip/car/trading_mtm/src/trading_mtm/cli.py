from __future__ import annotations

import os
from pathlib import Path
import pandas as pd
import typer
from rich.console import Console

from .mtm import compute_mtm_panel_all_dates, compute_mtm_report

app = typer.Typer(add_completion=False)
console = Console()


@app.command("generate-report")
def generate_report(
    input: Path = typer.Option(..., "--input", "-i", exists=True, help="Input Excel file containing Price and Contracts"),
    outdir: Path = typer.Option(Path("outputs"), "--outdir", "-o", help="Output directory"),
):
    """Generate MTM valuation report(s) from the provided dataset."""
    outdir.mkdir(parents=True, exist_ok=True)

    price = pd.read_excel(input, sheet_name="Price")
    contracts = pd.read_excel(input, sheet_name="Contracts")

    latest_date = pd.to_datetime(price["Price Date"]).max()
    report_latest = compute_mtm_report(contracts, price, latest_date)
    latest_xlsx = outdir / "mtm_report_latest.xlsx"
    latest_csv = outdir / "mtm_report_latest.csv"
    report_latest.to_excel(latest_xlsx, index=False)
    report_latest.to_csv(latest_csv, index=False)

    panel = compute_mtm_panel_all_dates(contracts, price)
    panel_csv = outdir / "mtm_report_all_dates.csv"
    panel.to_csv(panel_csv, index=False)

    console.print(f"[bold green]Generated[/] {latest_xlsx}, {latest_csv}, {panel_csv}")


def main():
    app()


if __name__ == "__main__":
    main()
