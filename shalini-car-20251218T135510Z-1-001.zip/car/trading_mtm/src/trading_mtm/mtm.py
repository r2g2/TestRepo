from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, date
from typing import Dict, Optional, Tuple

import pandas as pd
from dateutil.relativedelta import relativedelta


def _to_month_end(d: pd.Timestamp) -> pd.Timestamp:
    """Normalize a date to the last calendar day of that month."""
    d = pd.Timestamp(d).normalize()
    first_next = (d.replace(day=1) + relativedelta(months=1))
    return first_next - pd.Timedelta(days=1)


def normalize_index_name(name: str, aliases: Optional[Dict[str, str]] = None) -> str:
    name = (name or "").strip().upper()
    if aliases and name in aliases:
        return aliases[name]
    return name


def fe_adjustment_ratio(typical_fe) -> float:
    """
    No adjustment when contract indicates NoAdj; dataset provides Typical Fe.
    We treat missing or string 'NOADJ' as no adjustment.
    """
    if typical_fe is None or (isinstance(typical_fe, float) and pd.isna(typical_fe)):
        return 1.0
    if isinstance(typical_fe, str) and typical_fe.strip().upper() == "NOADJ":
        return 1.0
    return float(typical_fe) / 62.0


def quantity_to_dmt(quantity: float, unit: str, moisture: float) -> float:
    unit = (unit or "").strip().upper()
    q = float(quantity)
    if unit == "WMT":
        m = 0.0 if moisture is None or (isinstance(moisture, float) and pd.isna(moisture)) else float(moisture)
        return q * (1.0 - m)
    return q


def _last_available_price(
    price_df: pd.DataFrame,
    idx_name: str,
    tenor_end: pd.Timestamp,
    report_date: pd.Timestamp,
) -> Tuple[Optional[float], Optional[pd.Timestamp]]:
    """
    Find market price for (idx_name, tenor_end) at 'effective' price date:
    - if report_date > tenor_end, clamp to tenor_end
    - otherwise use report_date
    Then use last available market 'Price Date' on/before effective date.
    """
    effective = min(pd.Timestamp(report_date).normalize(), pd.Timestamp(tenor_end).normalize())
    sub = price_df[(price_df["Index Name"] == idx_name) & (price_df["Tenor"] == tenor_end)].copy()
    if sub.empty:
        return None, None
    sub = sub[sub["Price Date"] <= effective].sort_values("Price Date")
    if sub.empty:
        # if no price on/before effective, fallback to earliest available
        row = price_df[(price_df["Index Name"] == idx_name) & (price_df["Tenor"] == tenor_end)].sort_values("Price Date").head(1)
        if row.empty:
            return None, None
        return float(row["Price"].iloc[0]), pd.Timestamp(row["Price Date"].iloc[0]).normalize()
    row = sub.iloc[-1]
    return float(row["Price"]), pd.Timestamp(row["Price Date"]).normalize()


@dataclass(frozen=True)
class MTMConfig:
    index_aliases: Dict[str, str]


DEFAULT_CONFIG = MTMConfig(index_aliases={"PLATTS62": "PLTTS62"})


def compute_mtm_report(
    contracts_df: pd.DataFrame,
    price_df: pd.DataFrame,
    report_date: pd.Timestamp,
    config: MTMConfig = DEFAULT_CONFIG,
) -> pd.DataFrame:
    """Compute MTM report for a single report date."""
    # normalize price data
    p = price_df.copy()
    p["Price Date"] = pd.to_datetime(p["Price Date"]).dt.normalize()
    p["Tenor"] = pd.to_datetime(p["Tenor"]).dt.normalize()
    p["Index Name"] = p["Index Name"].astype(str).str.strip().str.upper()

    c = contracts_df.copy()
    c["Tenor"] = pd.to_datetime(c["Tenor"])
    c["Tenor End"] = c["Tenor"].apply(_to_month_end).dt.normalize()
    c["Base Index Norm"] = c["Base Index"].astype(str).map(lambda x: normalize_index_name(x, config.index_aliases))

    report_date = pd.to_datetime(report_date).normalize()

    rows = []
    for _, r in c.iterrows():
        idx = r["Base Index Norm"]
        tenor_end = r["Tenor End"]
        base_price, used_price_date = _last_available_price(p, idx, tenor_end, report_date)

        fe_ratio = fe_adjustment_ratio(r.get("Typical Fe"))
        cost = float(r.get("Cost", 0.0)) if not pd.isna(r.get("Cost", 0.0)) else 0.0
        disc = r.get("Discount", 1.0)
        disc = 1.0 if disc is None or (isinstance(disc, float) and pd.isna(disc)) else float(disc)

        qty_dmt = quantity_to_dmt(r.get("Quantity", 0.0), r.get("Unit", "DMT"), r.get("Moisture", 0.0))

        if base_price is None:
            mtm_val = np.nan
        else:
            mtm_val = (base_price * fe_ratio + cost) * disc * qty_dmt

        rows.append(
            {
                "Report Date": report_date,
                "Contract Ref": r.get("Contract_Ref"),
                "Counterparty": r.get("Counterparty"),
                "Base Index": r.get("Base Index"),
                "Base Index (Normalized)": idx,
                "Tenor (Contract)": pd.to_datetime(r.get("Tenor")).normalize(),
                "Tenor End (Month End)": tenor_end,
                "Market Price Date Used": used_price_date,
                "Base Index Price": base_price,
                "Typical Fe": r.get("Typical Fe"),
                "Fe Adjustment Ratio": fe_ratio,
                "Cost": cost,
                "Discount": disc,
                "Quantity": r.get("Quantity"),
                "Unit": r.get("Unit"),
                "Moisture": r.get("Moisture"),
                "Quantity (DMT)": qty_dmt,
                "MTM Value": mtm_val,
            }
        )

    out = pd.DataFrame(rows).sort_values(["Contract Ref"]).reset_index(drop=True)
    return out


def compute_mtm_panel_all_dates(
    contracts_df: pd.DataFrame, price_df: pd.DataFrame, config: MTMConfig = DEFAULT_CONFIG
) -> pd.DataFrame:
    """Compute MTM report for every distinct Price Date in market data."""
    all_dates = sorted(pd.to_datetime(price_df["Price Date"]).dt.normalize().unique())
    frames = [compute_mtm_report(contracts_df, price_df, d, config=config) for d in all_dates]
    return pd.concat(frames, ignore_index=True)
