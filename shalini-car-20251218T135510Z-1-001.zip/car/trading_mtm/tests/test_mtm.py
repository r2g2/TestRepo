import pandas as pd
from trading_mtm.mtm import fe_adjustment_ratio, quantity_to_dmt, _to_month_end

def test_fe_ratio_noadj():
    assert fe_adjustment_ratio("NoAdj") == 1.0
    assert fe_adjustment_ratio(None) == 1.0

def test_fe_ratio_numeric():
    assert abs(fe_adjustment_ratio(62.0) - 1.0) < 1e-9
    assert abs(fe_adjustment_ratio(63.0) - (63.0/62.0)) < 1e-9

def test_qty_wmt_to_dmt():
    assert abs(quantity_to_dmt(100, "WMT", 0.05) - 95.0) < 1e-9
    assert abs(quantity_to_dmt(100, "DMT", 0.05) - 100.0) < 1e-9

def test_month_end():
    assert _to_month_end(pd.Timestamp("2025-10-30")) == pd.Timestamp("2025-10-31")
