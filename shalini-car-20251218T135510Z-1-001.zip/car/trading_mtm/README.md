# Trading MTM Valuation – Reference Implementation (Python)

This folder contains a small, deployable-style solution to generate daily MTM valuation reports from the provided Excel.

## Quickstart

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -r requirements.txt
python -m trading_mtm.cli generate-report --input "data/Trading Case Example Data.xlsx" --outdir outputs
```

This will generate:
- `outputs/mtm_report_latest.xlsx` (latest available Price Date in the dataset)
- `outputs/mtm_report_latest.csv`
- `outputs/mtm_report_all_dates.csv` (panel report for all dates)

## Assumptions encoded from the case
- MTM = (BasePrice * FeRatio + Cost) * Discount * Quantity(DMT)
- FeRatio = 1 if Typical Fe is missing or equals "NoAdj"; else TypicalFe / 62
- Quantity conversion: if Unit=WMT then DMT = WMT * (1 - Moisture)
- Index aliasing: contracts may use `PLATTS62` while market uses `PLTTS62` (handled via a small alias map)
- Tenor alignment: contract tenor is normalized to month-end; market tenor may already be month-end.
- “Past tenor fixes” are implemented (if report date is after tenor end, price date is clamped to tenor end and we use the last available market price on/before that date for that tenor).

## Where to look
- `src/trading_mtm/mtm.py` core valuation logic
- `src/trading_mtm/cli.py` CLI entry point
- `tests/` includes basic unit tests for conversion and ratios
