import React, { useState, useRef, useEffect } from 'react';
import { Send, CloudRain, MessageSquare, Plus, Loader2 } from 'lucide-react';
import { sendQuery } from '../api/client';
import { Message } from '../types';

export const ChatInterface: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([
        {
            id: '1',
            role: 'assistant',
            content: "Hello! I'm your Weather Data Assistant. You can ask me about precipitation trends, compare districts, or get monthly analytics.",
            timestamp: new Date()
        }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMsg: Message = {
            id: Date.now().toString(),
            role: 'user',
            content: input,
            timestamp: new Date()
        };

        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsLoading(true);

        try {
            const data = await sendQuery(userMsg.content);

            const aiMsg: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: data.answer,
                table: data.table,
                timestamp: new Date()
            };
            setMessages(prev => [...prev, aiMsg]);
        } catch (error) {
            const errorMsg: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: "Sorry, I encountered an error processing your request. Please try again.",
                timestamp: new Date()
            };
            setMessages(prev => [...prev, errorMsg]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex h-screen bg-gray-50 font-sans text-slate-800">
            {/* Sidebar */}
            <div className="w-80 bg-white border-r border-slate-200 flex flex-col hidden md:flex">
                <div className="p-4 border-b border-slate-100">
                    <div className="flex items-center gap-2 mb-6 text-primary-dark font-semibold text-xl">
                        <CloudRain className="w-6 h-6" />
                        <span>Weather AI</span>
                    </div>
                    <button
                        onClick={() => setMessages([messages[0]])}
                        className="w-full bg-primary hover:bg-blue-700 text-white rounded-lg py-2 px-4 flex items-center justify-center gap-2 transition-colors"
                    >
                        <Plus className="w-4 h-4" />
                        New Chat
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-3">
                    <div className="text-xs font-semibold text-slate-400 mb-2 px-2 uppercase tracking-wide">Today</div>
                    <div className="bg-blue-50 text-blue-700 rounded-lg p-3 text-sm font-medium flex items-center gap-2 cursor-pointer">
                        <MessageSquare className="w-4 h-4" />
                        Current Session
                    </div>
                </div>
            </div>

            {/* Main Chat Area */}
            <div className="flex-1 flex flex-col h-full relative">
                <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-6 shrink-0">
                    <div>
                        <h1 className="text-lg font-bold text-slate-800">AI Weather Analyst</h1>
                        <p className="text-xs text-slate-500">Precipitation & Climate Insights</p>
                    </div>
                    <div className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                        Gemini 1.5 Pro
                    </div>
                </header>

                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                    {messages.map((msg) => (
                        <div
                            key={msg.id}
                            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                            <div className={`max-w-[80%] rounded-2xl p-5 shadow-sm 
                                ${msg.role === 'user'
                                    ? 'bg-primary text-white rounded-br-none'
                                    : 'bg-white border-l-4 border-primary text-slate-700 rounded-bl-none'
                                }`}
                            >
                                <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>

                                {/* Table Rendering */}
                                {msg.table && msg.table.length > 0 && (
                                    <div className="mt-4 overflow-x-auto rounded-lg border border-slate-200">
                                        <table className="w-full text-sm text-left text-slate-600">
                                            <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                                                <tr>
                                                    {Object.keys(msg.table[0]).map((header) => (
                                                        <th key={header} className="px-4 py-3 font-semibold">{header.replace(/_/g, ' ')}</th>
                                                    ))}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {msg.table.map((row, idx) => (
                                                    <tr key={idx} className="bg-white border-b hover:bg-slate-50 last:border-0">
                                                        {Object.values(row).map((val: any, i) => (
                                                            <td key={i} className="px-4 py-3">{val}</td>
                                                        ))}
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start">
                            <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center gap-2">
                                <Loader2 className="w-4 h-4 animate-spin text-primary" />
                                <span className="text-slate-500 text-sm">Analyzing data...</span>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 bg-white border-t border-slate-200 shrink-0">
                    <div className="max-w-4xl mx-auto relative flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask about precipitation, trends, or comparisons..."
                            className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-sm rounded-full py-3.5 pl-6 pr-12 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                            disabled={isLoading}
                        />
                        <button
                            onClick={handleSend}
                            disabled={!input.trim() || isLoading}
                            className="absolute right-2 p-2 bg-primary text-white rounded-full hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            <Send className="w-4 h-4" />
                        </button>
                    </div>
                    <div className="text-center mt-2">
                        <p className="text-[10px] text-slate-400">AI can make mistakes. Please verify important information.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};
