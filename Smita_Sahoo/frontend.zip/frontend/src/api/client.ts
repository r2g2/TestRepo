import axios from 'axios';
import { QueryResponse } from '../types';

const API_URL = 'http://localhost:8000/api';

export const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const sendQuery = async (question: string): Promise<QueryResponse> => {
    const response = await api.post<QueryResponse>('/query', { question });
    return response.data;
};
