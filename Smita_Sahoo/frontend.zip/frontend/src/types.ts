export interface QueryResponse {
    answer: string;
    table?: Record<string, any>[];
    metadata: {
        model?: string;
        intent?: string;
        sql?: string;
    };
}

export interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    table?: Record<string, any>[];
    timestamp: Date;
}
