from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from .agent import WeatherAgent
from .data_engine import DataEngine
import os

app = FastAPI(title="Weather Analysis API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Components
data_engine = DataEngine(
    daily_file=os.path.join("backend", "daily_precipitation.xlsx"),
    monthly_file=os.path.join("backend", "monthly_precipitation.xlsx")
)
agent = WeatherAgent(data_engine)

class QueryRequest(BaseModel):
    question: str

@app.get("/api/health")
def health_check():
    return {"status": "ok", "rows_daily": len(data_engine.daily_df), "rows_monthly": len(data_engine.monthly_df)}

@app.post("/api/query")
def chat(request: QueryRequest):
    try:
        result = agent.process_query(request.question)
        # Map to Frontend Schema
        return {
            "answer": result.get("response"),
            "table": result.get("data") if result.get("data") else [],
            "metadata": {
                "tool_used": result.get("tool_used"),
                "model": "gemini" # simplified
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
