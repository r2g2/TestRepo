import json
from ..adk.core import BaseAgent, AgentResponse
from backend.agent import WeatherAgent as NewWeatherAgent
from .data_service import data_service

class AgentServiceWrapper:
    def __init__(self):
        self.agent = NewWeatherAgent(data_service)

    async def process(self, input_text: str) -> AgentResponse:
        # Call the user's provided agent logic
        # process_query is synchronous in agent.py, so just call it.
        # Ideally if it does IO it should be async, but we'll run it directly here.
        result = self.agent.process_query(input_text)
        
        response_text = result.get("response", "No response generated")
        data = result.get("data")
        tool_used = result.get("tool_used")
        
        metadata = {
            "intent": tool_used if tool_used else "conversation",
            "sql": "Managed by agent.py", # agent.py doesn't expose SQL/query param details easily in return
            "table_data": data if isinstance(data, list) else None
        }
        
        return AgentResponse(
            content=response_text,
            metadata=metadata
        )

agent_service = AgentServiceWrapper()
