import google.generativeai as genai
from groq import Groq
import os
import json
import logging

logger = logging.getLogger(__name__)

class LLMService:
    def __init__(self):
        self.gemini_key = os.getenv("GEMINI_API_KEY")
        self.groq_key = os.getenv("GROQ_API_KEY")

        if self.gemini_key:
            genai.configure(api_key=self.gemini_key)
            self.gemini_model = genai.GenerativeModel('gemini-pro')

        if self.groq_key:
            self.groq_client = Groq(api_key=self.groq_key)

    def get_intent(self, question: str) -> dict:
        """
        Parses natural language question into structured intent.
        Strictly returns JSON.
        """
        prompt = f"""
        You are a Weather Data Intent Parser.
        Current Year is 2025.
        
        Analyze this question: "{question}"
        
        Return STRICT JSON matching this schema:
        {{
            "geography_level": "state" or "district",
            "metrics": "precipitation",
            "aggregation": "sum", "average", "compare", or "none",
            "time_range": {{ "start": "YYYY-MM-DD", "end": "YYYY-MM-DD" }} (infer full dates if just years/months given),
            "months": [int] (list of month numbers 1-12 if specific months mentioned, e.g. "Aug and Sep" -> [8, 9], else null),
            "granularity": "daily", "weekly", "monthly", or "yearly",
            "entities": ["list", "of", "state/district", "names"]
        }}
        
        Example: "Total rain in Pune in 2005"
        JSON: {{ "geography_level": "district", "metrics": "precipitation", "aggregation": "sum", "time_range": {{ "start": "2005-01-01", "end": "2005-12-31" }}, "months": null, "granularity": "yearly", "entities": ["Pune"] }}
        """

        try:
            return self._call_gemini_json(prompt)
        except Exception as e:
            logger.warning(f"Gemini Intent Parsing Failed: {e}. Switching to Groq.")
            return self._call_groq_json(prompt)

    def generate_answer(self, question: str, data: list) -> str:
        """
        Generates natural language answer based on the data.
        """
        data_preview = str(data)[:5000] # Truncate to fit context
        prompt = f"""
        Question: "{question}"
        Data Retrieved: {data_preview}
        
        Provide a clear, natural language answer. 
        If comparing, explicitly mention the difference.
        If data is empty, say no data found.
        """
        
        try:
            return self._call_gemini_text(prompt)
        except:
            return self._call_groq_text(prompt)

    def _call_gemini_json(self, prompt):
        # Enforce JSON mode via prompt engineering + cleanup
        response = self.gemini_model.generate_content(prompt + "\n\nRespond ONLY with JSON.")
        text = response.text
        # Clean markdown
        text = text.replace("```json", "").replace("```", "").strip()
        return json.loads(text)

    def _call_groq_json(self, prompt):
        completion = self.groq_client.chat.completions.create(
            messages=[{"role": "system", "content": "You are a JSON-only parser."}, {"role": "user", "content": prompt}],
            model="llama3-8b-8192",
            response_format={"type": "json_object"}
        )
        return json.loads(completion.choices[0].message.content)

    def _call_gemini_text(self, prompt):
        response = self.gemini_model.generate_content(prompt)
        return response.text

    def _call_groq_text(self, prompt):
        completion = self.groq_client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model="llama3-8b-8192",
        )
        return completion.choices[0].message.content
