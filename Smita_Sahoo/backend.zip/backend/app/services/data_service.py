import pandas as pd
import os
import duckdb
from datetime import datetime
import numpy as np

# Global cache for dataframes (simple in-memory for this assignment)
DATA_CACHE = {
    "daily": None,
    "monthly": None
}

class DataService:
    def __init__(self):
        self.daily_path = "daily_precipitation.xlsx"
        self.monthly_path = "monthly_precipitation.xlsx"
        self._load_data()

    def _load_data(self):
        if DATA_CACHE["daily"] is None:
            if os.path.exists(self.daily_path):
                print("Loading Daily Data...")
                DATA_CACHE["daily"] = pd.read_excel(self.daily_path)
                # Ensure types
                DATA_CACHE["daily"]['Date'] = pd.to_datetime(DATA_CACHE["daily"]['Date'])
            else:
                print("Daily Data not found. Using Mock.")
                DATA_CACHE["daily"] = self._generate_mock_daily()

        if DATA_CACHE["monthly"] is None:
            if os.path.exists(self.monthly_path):
                print("Loading Monthly Data...")
                DATA_CACHE["monthly"] = pd.read_excel(self.monthly_path)
            else:
                print("Monthly Data not found. Using Mock.")
                DATA_CACHE["monthly"] = self._generate_mock_monthly()

    def _generate_mock_daily(self):
        # ... (Reuse previous mock logic but simplified)
        dates = pd.date_range("2000-01-01", "2025-12-31", freq="D")
        # Small subset for perf in mock
        data = []
        for d in dates[::30]: # Create sparse mock to save generation time
            data.append({"Date": d, "State": "Maharashtra", "District": "Pune", "Daily Precipitation": np.random.rand()*10})
            data.append({"Date": d, "State": "Karnataka", "District": "Bangalore", "Daily Precipitation": np.random.rand()*10})
        return pd.DataFrame(data)

    def _generate_mock_monthly(self):
        return pd.DataFrame([
            {"Year": 2020, "Month": 8, "State": "Maharashtra", "District": "Pune", "Monthly Precipitation": 120.5},
            {"Year": 2020, "Month": 9, "State": "Maharashtra", "District": "Pune", "Monthly Precipitation": 90.0},
        ])

    def execute_intent(self, intent: dict) -> dict:
        """
        Executes the parsed intent against the data.
        Returns: { "data": [rows], "summary": "stats" }
        """
        granularity = intent.get("granularity", "daily").lower()
        entities = [e.lower() for e in intent.get("entities", [])]
        agg_type = intent.get("aggregation", "none").lower()
        
        # Select Dataset
        if granularity in ["monthly", "yearly"]:
            df = DATA_CACHE["monthly"].copy()
        else:
            df = DATA_CACHE["daily"].copy()

        # Filtering
        # 1. Geography
        if entities:
            # Check matches in State or District columns
            # Ideally intent should specify which entity maps to which column, 
            # but we'll do a loose match or rely on intent providing typed entities if possible.
            # For now, simplistic filter:
            mask = df['State'].str.lower().isin(entities) | df['District'].str.lower().isin(entities)
            df = df[mask]

        # 2. Time Range
        time_range = intent.get("time_range", {})
        if "start" in time_range and "end" in time_range:
            start = pd.to_datetime(time_range["start"])
            end = pd.to_datetime(time_range["end"])
            
            if "Date" in df.columns:
                df = df[(df["Date"] >= start) & (df["Date"] <= end)]
            elif "Year" in df.columns:
                df = df[(df["Year"] >= start.year) & (df["Year"] <= end.year)]
                # Could filter Month too if needed
        
        # 3. Specific filtering (e.g. Month names for "August and September")
        # If intent has explicit "months" list, filter by it.
        if "months" in intent:
             if "Date" in df.columns:
                 df = df[df["Date"].dt.month.isin(intent["months"])]
             elif "Month" in df.columns:
                 df = df[df["Month"].isin(intent["months"])]

        # Aggregation
        result_df = df
        if agg_type == "sum":
            col = "Daily Precipitation" if "Daily Precipitation" in df.columns else "Monthly Precipitation"
            # Group by relevant cols (State/District + Time period)
            group_cols = ["State", "District"]
            if granularity == "yearly":
                if "Year" in df.columns: group_cols.append("Year")
                elif "Date" in df.columns: 
                    df["Year"] = df["Date"].dt.year
                    group_cols.append("Year")
            
            result_df = df.groupby(group_cols)[col].sum().reset_index()
            
        elif agg_type == "average":
            col = "Daily Precipitation" if "Daily Precipitation" in df.columns else "Monthly Precipitation"
            result_df = df.groupby(["State", "District"])[col].mean().reset_index()

        # Comparison (usually just returning the table of requested entities allows valid comparison)
        
        return result_df.to_dict(orient="records")

    def query_daily_precipitation(self, start_date=None, end_date=None, state=None, district=None):
        df = DATA_CACHE["daily"].copy()
        
        # Date Filter
        if "Date" in df.columns:
            if start_date:
                df = df[df["Date"] >= pd.to_datetime(start_date)]
            if end_date:
                df = df[df["Date"] <= pd.to_datetime(end_date)]
                
        # Location Filter
        if state:
            df = df[df["State"].astype(str).str.lower() == state.lower()]
        if district:
            df = df[df["District"].astype(str).str.lower() == district.lower()]
            
        return df.to_dict(orient="records")

    def query_monthly_precipitation(self, start_year=None, end_year=None, months=None, state=None, district=None):
        df = DATA_CACHE["monthly"].copy()
        
        # Year Filter
        if "Year" in df.columns:
            if start_year:
                df = df[df["Year"] >= int(start_year)]
            if end_year:
                df = df[df["Year"] <= int(end_year)]
                
        # Month Filter
        if months and "Month" in df.columns:
            df = df[df["Month"].isin(months)]
            
        # Location Filter
        if state:
             df = df[df["State"].astype(str).str.lower() == state.lower()]
        if district:
             df = df[df["District"].astype(str).str.lower() == district.lower()]
             
        return df.to_dict(orient="records")


data_service = DataService()