import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

def generate_mock_data(output_dir="backend/data"):
    print(f"Generating mock data in {output_dir}...")
    
    # Configuration
    start_date = datetime(2020, 1, 1)
    end_date = datetime(2023, 12, 31)
    states = {
        "Maharashtra": ["Pune", "Mumbai", "Nagpur", "Nashik"],
        "Karnataka": ["Bangalore", "Mysore", "Hubli", "Mangalore"],
        "Kerala": ["Kochi", "Thiruvananthapuram", "Kozhikode"],
        "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"]
    }
    
    # Generate Daily Data
    records = []
    current_date = start_date
    delta = timedelta(days=1)
    
    dates = []
    while current_date <= end_date:
        dates.append(current_date)
        current_date += delta
        
    for date in dates:
        for state, districts in states.items():
            for district in districts:
                # Simulate precipitation (more in monsoon: June-Sept)
                is_monsoon = date.month in [6, 7, 8, 9]
                if is_monsoon:
                    precip = np.random.gamma(shape=2, scale=10) # Heavy rain distribution
                else:
                    precip = np.random.exponential(scale=2) # Light/No rain
                
                # Occasionally 0 rain
                if np.random.random() < 0.3:
                    precip = 0.0
                    
                records.append({
                    "date": date,
                    "state": state,
                    "district": district,
                    "daily_precipitation": round(precip, 2)
                })
    
    daily_df = pd.DataFrame(records)
    daily_file = os.path.join(output_dir, "daily_precipitation.csv")
    daily_df.to_csv(daily_file, index=False)
    print(f"Saved {daily_file} with {len(daily_df)} rows")
    
    # Generate Monthly Data
    daily_df['year'] = daily_df['date'].dt.year
    daily_df['month'] = daily_df['date'].dt.month
    
    monthly_df = daily_df.groupby(['year', 'month', 'state', 'district'])['daily_precipitation'].sum().reset_index()
    monthly_df.rename(columns={'daily_precipitation': 'monthly_precipitation'}, inplace=True)
    
    monthly_file = os.path.join(output_dir, "monthly_precipitation.csv")
    monthly_df.to_csv(monthly_file, index=False)
    print(f"Saved {monthly_file} with {len(monthly_df)} rows")

if __name__ == "__main__":
    if not os.path.exists("backend/data"):
        os.makedirs("backend/data")
    generate_mock_data()
