from fastapi import APIRouter, HTTPException
from app.models.schemas import QueryRequest, QueryResponse
from app.services.llm_service import LLMService
from app.services.data_service import DataService

router = APIRouter()
llm_service = LLMService()
data_service = DataService()

@router.post("/query", response_model=QueryResponse)
async def query_weather(request: QueryRequest):
    try:
        # 1. Intent Parsing
        intent = llm_service.get_intent(request.question)
        print(f"Parsed Intent: {intent}")

        # 2. Data Execution (Deterministic)
        data = data_service.execute_intent(intent)
        
        # 3. Answer Generation
        answer = llm_service.generate_answer(request.question, data)
        
        return QueryResponse(
            answer=answer,
            table=data,
            metadata={
                "intent": intent,
                "model_used": "auto (gemini/groq)"
            }
        )
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail=str(e))
