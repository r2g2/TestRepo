from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from ..services.agent_service import agent_service
from ..services.data_service import data_service

router = APIRouter()

class QueryRequest(BaseModel):
    question: str

class QueryResponse(BaseModel):
    answer: str
    table: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any]

@router.get("/health")
async def health_check():
    return {"status": "ok", "service": "weather-analytics-backend"}

@router.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    try:
        # 1. Process via ADK Agent
        response = await agent_service.process(request.question)
        
        # 2. Extract Data
        # AgentResponse(content=..., metadata={"sql":..., "raw_plan":...})
        
        return {
            "answer": response.content,
            "table": response.metadata.get("table_data"),
            "metadata": {
                "model": "gemini-1.5-flash", # ToDo: dynamic prop from agent
                "intent": response.metadata.get("intent", "unknown"),
                "sql": response.metadata.get("sql", "N/A")
            }
        }
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
