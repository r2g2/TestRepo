from pydantic import BaseModel
from typing import List, Optional, Any, Dict

class QueryRequest(BaseModel):
    question: str

class Intent(BaseModel):
    geography_level: str  # state | district
    metrics: str = "precipitation"
    aggregation: str # sum | average | compare | none (raw)
    time_range: Dict[str, Any] # {start, end} or specific dates
    granularity: str # daily | weekly | monthly | yearly
    entities: List[str] # [State A, District B]

class QueryResponse(BaseModel):
    answer: str
    table: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any]
