from typing import List, Dict, Any, Optional, Callable
import inspect
from pydantic import BaseModel

class Tool(BaseModel):
    name: str
    description: str
    func: Callable
    parameters: dict

    @classmethod
    def from_func(cls, func: Callable):
        sig = inspect.signature(func)
        doc = inspect.getdoc(func) or "No description"
        params = {}
        for name, param in sig.parameters.items():
            params[name] = {"type": str(param.annotation), "default": str(param.default)}
            
        return cls(
            name=func.__name__,
            description=doc,
            func=func,
            parameters=params
        )

    async def execute(self, **kwargs):
        if inspect.iscoroutinefunction(self.func):
            return await self.func(**kwargs)
        return self.func(**kwargs)

class AgentResponse(BaseModel):
    content: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any] = {}

class BaseAgent:
    def __init__(self, name: str, tools: List[Tool] = [], model_config: Dict = {}):
        self.name = name
        self.tools = {t.name: t for t in tools}
        self.model_config = model_config
        self.history = []

    async def process(self, input_text: str) -> AgentResponse:
        raise NotImplementedError("Subclasses must implement process")
