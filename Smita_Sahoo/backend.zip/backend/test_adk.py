try:
    import google.adk
    print("google.adk imported successfully")
    print(dir(google.adk))
except ImportError:
    print("Failed to import google.adk")
except Exception as e:
    print(f"Error: {e}")
