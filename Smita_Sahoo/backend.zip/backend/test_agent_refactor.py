import asyncio
from app.services.agent_service import WeatherAgent, AgentResponse

async def test_agent():
    print("Initializing WeatherAgent...")
    agent = WeatherAgent()
    
    # Mock LLM for testing without keys
    async def mock_call_llm(prompt):
        print(f"LLM Called with prompt length: {len(prompt)}")
        if "Output JSON only" in prompt:
            return '```json\n{"intent": "test", "sql": "SELECT * FROM daily LIMIT 2", "reasoning": "Test query"}\n```'
        return "This is a mock answer based on data."

    agent._call_llm = mock_call_llm
    
    print("Processing query...")
    response = await agent.process("Test precipitation query")
    
    print(f"Response Content: {response.content}")
    print(f"Metadata: {response.metadata}")
    
    if isinstance(response, AgentResponse) and response.metadata.get("sql"):
        print("SUCCESS: Agent returned valid AgentResponse with SQL.")
    else:
        print("FAILURE: Invalid response structure.")

if __name__ == "__main__":
    asyncio.run(test_agent())
