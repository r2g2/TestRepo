import sys
import os
import asyncio

# Ensure backend directory is in path
sys.path.append(os.path.join(os.getcwd(), 'backend'))

from backend.app.services.agent_service import agent_service

async def test_integration():
    print("Testing Integrated Agent...")
    
    # Mock query
    response = await agent_service.process("Get precipitation for Pune in August 2021")
    
    print(f"Response: {response.content}")
    print(f"Metadata: {response.metadata}")
    
    if response.content:
        print("SUCCESS: Received response from integrated agent.")
    else:
        print("FAILURE: No content in response.")

if __name__ == "__main__":
    asyncio.run(test_integration())
