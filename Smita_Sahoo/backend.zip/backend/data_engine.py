import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

class DataEngine:
    def __init__(self, daily_file="daily_precipitation_v2.xlsx", monthly_file="monthly_precipitation_v2.xlsx"):
        self.daily_file = daily_file
        self.monthly_file = monthly_file
        self.daily_df = None
        self.monthly_df = None
        self._load_data()

    def _load_data(self):
        """Loads data from Excel files or generates mock data if not found."""
        try:
            if os.path.exists(self.daily_file):
                print(f"Loading daily data from {self.daily_file}...")
                self.daily_df = pd.read_excel(self.daily_file)
            else:
                print("Daily data file not found. Generating mock data...")
                self.daily_df = self._generate_mock_daily_data()

            if os.path.exists(self.monthly_file):
                print(f"Loading monthly data from {self.monthly_file}...")
                self.monthly_df = pd.read_excel(self.monthly_file)
            else:
                print("Monthly data file not found. Generating mock data...")
                self.monthly_df = self._generate_mock_monthly_data() # Usually derived, but we'll mock for consistency

            # Ensure proper types
            self.daily_df['Date'] = pd.to_datetime(self.daily_df['Date'])
            self.daily_df['Daily Precipitation'] = pd.to_numeric(self.daily_df['Daily Precipitation'], errors='coerce').fillna(0.0)
            
            # Indexing for performance
            self.daily_df.sort_values('Date', inplace=True)
            
        except Exception as e:
            print(f"Error loading data: {e}")
            # Fallback to empty formatted DF to prevent crashes
            self.daily_df = pd.DataFrame(columns=['Date', 'State', 'District', 'Daily Precipitation'])
            self.monthly_df = pd.DataFrame(columns=['Year', 'Month', 'State', 'District', 'Monthly Precipitation'])

    def _generate_mock_daily_data(self):
        """Generates mock daily precipitation data."""
        start_date = datetime(2000, 1, 1)
        end_date = datetime(2025, 12, 31)
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        
        states = ['Uttar Pradesh', 'Maharashtra', 'Karnataka', 'Kerala']
        districts = {
            'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Varanasi'],
            'Maharashtra': ['Mumbai', 'Pune', 'Nagpur'],
            'Karnataka': ['Bangalore', 'Mysore'],
            'Kerala': ['Kochi', 'Thiruvananthapuram']
        }
        
        data = []
        # Generate a smaller subset for mock to be fast, or a reasonable amount
        # For >1M rows simulation, we'd need more, but let's keep it manageable for dev
        # Let's do just last 5 years + 2000-2005 for the specific query examples
        
        target_years = list(range(2000, 2006)) + list(range(2020, 2026))
        filtered_dates = [d for d in date_range if d.year in target_years]
        
        for d in filtered_dates:
            for state in states:
                for district in districts[state]:
                    precip = np.random.gamma(shape=2.0, scale=2.0) if np.random.rand() > 0.7 else 0.0
                    data.append({
                        'Date': d,
                        'State': state,
                        'District': district,
                        'Daily Precipitation': round(precip, 2)
                    })
        
        return pd.DataFrame(data)

    def _generate_mock_monthly_data(self):
        """Generates mock monthly data based on the daily mock data logic."""
        # Ideally this should be aggregated from daily, but for mock we can just aggregate the current self.daily_df
        if self.daily_df is not None and not self.daily_df.empty:
            df = self.daily_df.copy()
            df['Year'] = df['Date'].dt.year
            df['Month'] = df['Date'].dt.month
            monthly = df.groupby(['Year', 'Month', 'State', 'District'])['Daily Precipitation'].sum().reset_index()
            monthly.rename(columns={'Daily Precipitation': 'Monthly Precipitation'}, inplace=True)
            return monthly
        return pd.DataFrame(columns=['Year', 'Month', 'State', 'District', 'Monthly Precipitation'])

    def query_daily_precipitation(self, start_date=None, end_date=None, location=None, state=None, district=None, **kwargs):
        """Queries daily precipitation data with liberal matching."""
        df = self.daily_df
        if start_date:
            df = df[df['Date'] >= pd.to_datetime(start_date)]
        if end_date:
            df = df[df['Date'] <= pd.to_datetime(end_date)]
            
        if location:
            # Liberal search: Match State OR District
            term = location.lower().replace(" ", "")
            # boolean mask
            mask = (
                (df['State'].str.lower().str.replace(" ", "") == term) | 
                (df['District'].str.lower().str.replace(" ", "") == term)
            )
            df = df[mask]
        else:
            # Fallback to specific columns if location not provided
            if state:
                state_clean = state.lower().replace(" ", "")
                df = df[df['State'].str.lower().str.replace(" ", "") == state_clean]
            if district:
                district_clean = district.lower().replace(" ", "")
                df = df[df['District'].str.lower().str.replace(" ", "") == district_clean]
                
        return df.to_dict(orient='records')

    def query_monthly_precipitation(self, start_year=None, end_year=None, location=None, months=None, state=None, district=None, **kwargs):
        """Queries monthly precipitation data.
        months: list of integers (1-12)
        """
        df = self.monthly_df
        if start_year:
            df = df[df['Year'] >= start_year]
        if end_year:
            df = df[df['Year'] <= end_year]
        if months:
            df = df[df['Month'].isin(months)]
            
        if location:
            # Liberal search: Match State OR District
            term = location.lower().replace(" ", "")
            # boolean mask
            mask = (
                (df['State'].str.lower().str.replace(" ", "") == term) | 
                (df['District'].str.lower().str.replace(" ", "") == term)
            )
            df = df[mask]
        else:
            if state:
                state_clean = state.lower().replace(" ", "")
                df = df[df['State'].str.lower().str.replace(" ", "") == state_clean]
            if district:
                district_clean = district.lower().replace(" ", "")
                df = df[df['District'].str.lower().str.replace(" ", "") == district_clean]
        return df.to_dict(orient='records')

    def get_weather_data(self, dataset_type, location=None, date=None, start_date=None, end_date=None, year=None, **kwargs):
        """Unified method for agent to get data."""
        if dataset_type == 'daily':
            # Handle single date convenience
            s_date = start_date or date
            e_date = end_date or date
            return self.query_daily_precipitation(start_date=s_date, end_date=e_date, location=location)
        elif dataset_type == 'monthly':
            return self.query_monthly_precipitation(start_year=year, end_year=year, location=location)
        return []
