import os
import google.generativeai as genai
from groq import Groq
from dotenv import load_dotenv
import json
import logging
import re

load_dotenv()

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WeatherAgent:
    def __init__(self, data_engine):
        self.data_engine = data_engine
        self.gemini_key = os.getenv("GEMINI_API_KEY")
        self.groq_key = os.getenv("GROQ_API_KEY")
        self.groq_model = os.getenv("GROQ_MODEL", "llama3-8b-8192")
        
        # Tools definition for the LLM
        self.tools = [
            {
                "name": "get_weather_data",
                "description": "Get weather data from local database.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "dataset_type": {"type": "string", "enum": ["daily", "monthly"], "description": "Type of data to fetch"},
                        "location": {"type": "string", "description": "State or District name"},
                        "date": {"type": "string", "description": "For daily: Specific date (YYYY-MM-DD)"},
                        "start_date": {"type": "string", "description": "For daily: Start date (YYYY-MM-DD)"},
                        "end_date": {"type": "string", "description": "For daily: End date (YYYY-MM-DD)"},
                        "year": {"type": "integer", "description": "For monthly: Year (e.g. 2000)"}
                    }
                }
            },
            {
                "name": "chat_reply",
                "description": "Reply to greetings or general conversation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string", "description": "The response message"}
                    },
                    "required": ["content"]
                }
            }
        ]

    def _call_gemini(self, prompt, history=[]):
        if not self.gemini_key:
            raise Exception("Gemini API Key missing")
        
        genai.configure(api_key=self.gemini_key)
        model = genai.GenerativeModel('gemini-pro')
        
        full_prompt = f"""
        User Query: {prompt}
        
        You are a Weather Database Interface.
        YOUR JOB:
        1. If it's a greeting, use `chat_reply`.
        2. If it's a data request, use `get_weather_data`.
        3. Convert the user's request into a JSON tool call.
        4. DO NOT use lat/lon coordinates. Use location names (State/District).
        
        TOOLS:
        1. get_weather_data(dataset_type, location, date, year, ...)
           - dataset_type: "daily" (dates/days) OR "monthly" (months/years)
        2. chat_reply(content)
           - content: text response
        
        EXAMPLE RESPONSES:
        User: "Hi, how are you?"
        Response: {{ "tool": "chat_reply", "args": {{ "content": "Hello! I am your weather assistant." }} }}
        
        User: "Rain in Uttar Pradesh on 1st Jan 2000"
        Response: {{ "tool": "get_weather_data", "args": {{ "dataset_type": "daily", "location": "Uttar Pradesh", "date": "2000-01-01" }} }}
        Response: {{ "tool": "get_weather_data", "args": {{ "dataset_type": "daily", "location": "Uttar Pradesh", "date": "2000-01-01" }} }}
        
        User: "Monthly rain in Pune 2005"
        Response: {{ "tool": "get_weather_data", "args": {{ "dataset_type": "monthly", "location": "Pune", "year": 2005 }} }}
        
        Output ONLY valid JSON for tools, OR plain text for conversation.
        """
        
        response = model.generate_content(full_prompt)
        return response.text

    def _call_groq(self, prompt, history=[]):
        if not self.groq_key:
            raise Exception("Groq API Key missing")
        
        client = Groq(api_key=self.groq_key)
        
        full_prompt = f"""
        You are a Weather Database Interface.
        Query: {prompt}
        1. If it's a greeting, reply plain text.
        2. Else, output ONLY a JSON tool call to `get_weather_data`.
        """
        
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": full_prompt},
                {"role": "user", "content": prompt}
            ],
            model=self.groq_model,
        )
        return chat_completion.choices[0].message.content

    def process_query(self, user_query):
        try:
            # 1. Try Gemini
            try:
                logger.info("Attempting Gemini...")
                response_text = self._call_gemini(user_query)
            except Exception as e:
                logger.error(f"Gemini failed: {e}. Switching to Groq.")
                response_text = self._call_groq(user_query)

            # DEBUG: Log to file
            try:
                with open("last_response.txt", "w", encoding="utf-8") as f:
                    f.write(str(response_text))
            except:
                pass

            # 2. Check for Tool Call (JSON or Python-string)
            tool_call = None
            
            # A. Try JSON Regex
            json_match = re.search(r"\{.*\}", response_text, re.DOTALL)
            if json_match:
                try:
                    tool_call = json.loads(json_match.group(0))
                    # Normalize keys (handle function/params mismatch)
                    if "function" in tool_call and "tool" not in tool_call:
                        tool_call["tool"] = tool_call["function"]
                    if "params" in tool_call and "args" not in tool_call:
                        tool_call["args"] = tool_call["params"]
                    if "arguments" in tool_call and "args" not in tool_call:
                        tool_call["args"] = tool_call["arguments"]
                except:
                    pass
            
            # B. Try Python-style string Regex (Fallback)
            if not tool_call:
                # Matches: get_weather_data('Uttar Pradesh', '2000-01-01', ...)
                func_match = re.search(r"get_weather_data\((.*)\)", response_text, re.DOTALL)
                if func_match:
                    args_str = func_match.group(1)
                    # Try to parse the arguments
                    # Case 1: The args string is a single JSON object? e.g. get_weather_data({"a":1})
                    try:
                        import ast
                        # 1. Try Standard JSON
                        try:
                            json_arg = json.loads(args_str)
                        except:
                            # 2. Try Python Literal Eval (handles single quotes)
                            try:
                                json_arg = ast.literal_eval(args_str)
                            except:
                                json_arg = None
                        
                        if isinstance(json_arg, dict):
                            tool_call = {"tool": "get_weather_data", "args": json_arg}
                            # Map keys if needed (e.g. state -> location)
                            if "state" in json_arg and "location" not in json_arg:
                                tool_call["args"]["location"] = json_arg["state"]
                            if "day" in json_arg and "month" in json_arg and "year" in json_arg:
                                # Construct date
                                tool_call["args"]["date"] = f"{json_arg['year']}-{json_arg['month']:02d}-{json_arg['day']:02d}"
                                tool_call["args"]["dataset_type"] = "daily"
                            logger.info(f"Parsed JSON/Dict-arg tool call: {tool_call}")
                    except Exception as e:
                        logger.error(f"Arg parsing failed: {e}")

                    if not tool_call:
                        # Case 2: Comma separated args (Legacy fallback)
                        clean_args = [a.strip().strip("'").strip('"') for a in args_str.split(",")]
                        
                        tool_call = {"tool": "get_weather_data", "args": {}}
                        
                        # Heuristic parsing
                        for arg in clean_args:
                            # Date Pattern
                            if re.match(r"\d{4}-\d{2}-\d{2}", arg):
                                tool_call["args"]["date"] = arg
                                tool_call["args"]["dataset_type"] = "daily"
                            # Year Pattern
                            elif re.match(r"^\d{4}$", arg):
                                tool_call["args"]["year"] = int(arg)
                                tool_call["args"]["dataset_type"] = "monthly"
                            # Explicit Type
                            elif arg.lower() in ["daily", "monthly"]:
                                tool_call["args"]["dataset_type"] = arg.lower()
                            # Location (fallback)
                            elif arg.lower() not in ["['precipitation']", "[precipitation]"]:
                                tool_call["args"]["location"] = arg
                        
                        logger.info(f"Parsed Python-style tool call: {tool_call}")

            # Trace Log
            debug_info = f"Query: {user_query}\nResponse: {response_text}\nToolCall: {tool_call}\n"
            
            if tool_call and "tool" in tool_call:
                # Use parsed tool name
                tool_name = tool_call["tool"]
                args = tool_call.get("args", {})
                
                if tool_name == "chat_reply":
                    with open("debug_flow_log.txt", "w") as f: f.write(debug_info + "Action: Chat Reply\n")
                    return {
                        "response": args.get("content", "Hello! I am your weather assistant."),
                        "data": None,
                        "tool_used": "chat_reply"
                    }

                # Standardize to weather tool if not chat (or fallback)
                if tool_name != "get_weather_data":
                     tool_name = "get_weather_data"
                
                args = tool_call.get("args", {})
                
                # Default dataset_type if missing
                if "dataset_type" not in args:
                    if "date" in args or "start_date" in args:
                        args["dataset_type"] = "daily"
                    elif "year" in args:
                        args["dataset_type"] = "monthly"
                    else:
                        args["dataset_type"] = "daily"
                         
                logger.info(f"Executing tool: {tool_name} with args {args}")
                 
                data = self.data_engine.get_weather_data(**args)
                logger.info(f"DATA RETRIEVED COUNT: {len(data) if data else 0}")
                
                with open("debug_flow_log.txt", "w") as f: f.write(debug_info + f"Action: Tool {tool_name}\nData Count: {len(data)}\n")

                # 3. Generate Final Answer with Data
                analysis_prompt = f"""
                User Question: {user_query}
                Data Retrieved: {str(data)[:10000]}
                
                INSTRUCTION:
                1. The data above IS the ground truth. Use it to answer the question.
                2. If the data contains 0.0, this means NO RAIN (0 mm). This IS valid data.
                3. Do NOT say "data is unavailable" if you see 0.0. Say "The precipitation was 0 mm" or "There was no rain".
                4. Summarize the precipitation values, dates, and locations in a clear Text table format or bullet points.
                5. DO NOT output raw JSON in your final answer. Write natural language.
                6. If the LIST is truly empty (e.g. []), ONLY THEN say "No precipitation records found for this specific date/location."
                """
                
                # Call LLM again for final synthesis
                try:
                    final_response = self._call_gemini(analysis_prompt)
                except:
                    final_response = self._call_groq(analysis_prompt)
                    
                return {
                    "response": final_response,
                    "data": data, # Return raw data for frontend visualization
                    "tool_used": tool_name
                }
                
            # If no JSON found or no tool in JSON
            with open("debug_flow_log.txt", "w") as f: f.write(debug_info + "Action: No Tool\n")
            return {"response": response_text, "data": None}

        except Exception as e:
            return {"response": f"Error processing request: {str(e)}", "data": None}
